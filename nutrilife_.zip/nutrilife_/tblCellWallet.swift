//
//  tblCellWallet.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 31/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class tblCellWallet: UITableViewCell
{
    //----------------------------
    // MARK: Outlets
    //----------------------------
    
    @IBOutlet weak var lblTransactionTitle: UILabel!
    
    @IBOutlet weak var lblTransactionDetail: UILabel!
    
    @IBOutlet weak var lblDateTime: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
