//
//  tblCellPaymentCurrency.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 02/11/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class tblCellPaymentCurrency: UITableViewCell
{
    //-----------------------------
    // MARK: Outlets
    //-----------------------------

    @IBOutlet weak var lblCurrency: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
