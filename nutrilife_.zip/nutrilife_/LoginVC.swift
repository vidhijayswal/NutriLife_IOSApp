//
//  LoginVC.swift
//  NutriLife
//
//

import UIKit
import Alamofire
import SVProgressHUD

class LoginVC: UIViewController, UITextFieldDelegate
{
    
    

    //----------------------------
    // MARK: Outlets
    //----------------------------
    @IBOutlet var myview: UIView!
    
    @IBOutlet weak var lblEmailIDPlaceholder: UILabel!
    
    @IBOutlet weak var txtEmailID: UITextField!
    
    @IBOutlet weak var lblEmailIDError: UILabel!
    
    @IBOutlet weak var lblPasswordPlaceholder: UILabel!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var lblPasswordError: UILabel!
    
    
    //----------------------------
    // MARK: Identifiers
    //----------------------------
    
    var email = String()
    var password = String()
    var timer = Timer()
    var role = Int()
    


    //----------------------------
    // MARK: View Life Cycle
    //----------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
        print(appDelegate.FirebaseToken!)
        txtEmailID.delegate = self
        txtPassword.delegate = self
        lblPasswordError.isHidden = true
        lblPasswordPlaceholder.isHidden = true
        lblEmailIDPlaceholder.isHidden = true
        lblEmailIDError.isHidden = true
        txtEmailID.addTarget(self, action: #selector(txtEmailIDValueChanged), for: .editingChanged)
        txtPassword.addTarget(self, action: #selector(txtPasswordValueChanged), for: .editingChanged)
    }
    

    //----------------------------
    // MARK: Delegate Method
    //----------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        self.view.endEditing(true)
        return true
    }
    
    //----------------------------
    // MARK: User Defined Function
    //----------------------------
    
    @objc func txtEmailIDValueChanged()
    {
        if txtEmailID.text == ""
        {
            lblEmailIDPlaceholder.isHidden = true
            lblEmailIDError.isHidden = false
        }
        else
        {
            lblEmailIDPlaceholder.isHidden = false
            lblEmailIDError.isHidden = true
            
        }
    }
    
    
    
    @objc func txtPasswordValueChanged()
    {
        if txtPassword.text == ""
        {
            lblPasswordPlaceholder.isHidden = true
            lblPasswordError.isHidden = false
        }
        else
        {
            lblPasswordPlaceholder.isHidden = false
            lblPasswordError.isHidden = true
            
        }
    }
    
    
    
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            login()
            
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    
    //----------------------------
    // MARK: Button Actions
    //----------------------------
    
    @IBAction func btnForgotPasswordTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "ResetPasswordVC") as! ResetPasswordVC
        self.navigationController?.pushViewController(obj, animated: true)
        
    }
    
    
    
    @IBAction func btnCreateNewAccountTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "IdentificationVC") as! IdentificationVC
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    
    @IBAction func btnLoginTUI(_ sender: UIButton)
    {
        if txtEmailID.text == ""
        {
            lblEmailIDError.isHidden = false
        }
        
        else if txtPassword.text == ""
        {
            lblPasswordError.isHidden = false
        }
        
        else
        {
            login()
        }
        
    }
    
    
    
    @IBAction func btnLoginGoogleTUI(_ sender: UIButton)
    {
        
    }
    
    @IBAction func btnLoginFacebookTUI(_ sender: UIButton)
    {
        
    }
    
    
    //----------------------------
    // MARK: Web Services
    //----------------------------

    
    
//    "{
//    ""login_type"":1,
//    ""fcm_id"":""abc123"",
//    ""device"":""android"",
//    ""email"":""shreeraj.qrioustech@gmail.com"",
//    ""password"":""admin@123""
//}
//
//For Social Login:
//
//Keys:
//"user_id" : UserDefaults.standard.integer(forKey: "userId")
//email , fname , lname , device , fcm_id , login_type

    func login()
    {
            
            let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["login_type": 1, "fcm_id": appDelegate.FirebaseToken!, "device": "ios", "email": txtEmailID.text!, "password": txtPassword.text!] as [String : Any]
            print(parameter)
            if Connectivity.isConnectedToInternet()
            {
                timer.invalidate()
                SVProgressHUD.show()
                print(appDelegate.apiString + "login")
                Alamofire.request( appDelegate.apiString + "login" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                    {
                        response in
                        switch response.result
                        {
                        case .success:
                            print("Login Successful")
                            let result = response.result.value! as! NSDictionary
                            print(result)
                            UserDefaults.standard.set("1", forKey: "isLogin")
                            if (result["status"] as! Int) == 0
                            {
                               SVProgressHUD.dismiss()
                                PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            }
                            else
                            {
                                SVProgressHUD.dismiss()
                                
                                let data = result["data"] as! NSDictionary
                                
                                login_time = data["login_times"] as! Int
                                
                                UserDefaults.standard.set((data["user_id"] as! Int), forKey: "userId")
                                if (data["role"] as! Int) == 1
                                {
                                    
                                    UserDefaults.standard.set("doctor", forKey: "userrole")
                                    
                                    if (data["login_times"] as! Int) == 1
                                    {
                                        let obj = self.storyboard?.instantiateViewController(withIdentifier: "CertificateVC") as! CertificateVC
                                        
                                        self.navigationController?.pushViewController(obj, animated: true)
                                    }
                                    
                                    else
                                    {
                                        
                                        let obj = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
                                        
                                        self.navigationController?.pushViewController(obj, animated: true)
                                    }
                                    
                                    

                                }
                                
                                else
                                {
                                    UserDefaults.standard.set("patient", forKey: "userrole")
                                    
                                    if (data["login_times"] as! Int) == 1
                                    {
                                        let obj = self.storyboard?.instantiateViewController(withIdentifier: "BMIVC") as! BMIVC
                                        
                                        self.navigationController?.pushViewController(obj, animated: true)
                                    }
                                    
                                    else
                                    {
                                        
                                        let obj = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
                                        
                                        self.navigationController?.pushViewController(obj, animated: true)
                                    }
                                }
                            }
                        case .failure(let error):
                            print(error)
                        }
                }
            }
            else
            {
                self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
                PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
            }
}
    
}
