//
//  CertificateVC.swift
//  NutriLife
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD
import SDWebImage

class CertificateVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    
    //------------------------------
    // MARK: Outlets
    //------------------------------
    
    @IBOutlet weak var tblCertificate: UITableView!
    
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var btnBack1: UIButton!
    
    @IBOutlet weak var lblLabel: UILabel!
    //------------------------------
    // MARK: Identifiers
    //------------------------------
    
    var timer = Timer()
    var certificatedata = NSMutableArray()
    var certificateId = Int()
    var doctoridentification = Int()

    //------------------------------
    // MARK: View Life Cycle
    //------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
           // btnAdd.isHidden = false
            if login_time == 1
            {
                btnBack1.isHidden = true
                lblLabel.isHidden = false
                tblCertificate.isHidden = true
            }
            else
            {
                btnBack1.isHidden = false
                lblLabel.isHidden = true
                tblCertificate.isHidden = false
            }
            certificates()
            
        }
        else
        {
            patientidcertificates()
            btnAdd.isHidden = true
        }
        
        
        
        
        
    }
    

    //------------------------------
    // MARK: Delegate Methods
    //------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return certificatedata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let obj = tblCertificate.dequeueReusableCell(withIdentifier: "tblCellCertificate") as! tblCellCertificate
        
        if UserDefaults.standard.string(forKey: "userrole") == "doctor"

        {
            let dic = certificatedata[indexPath.row] as! NSDictionary

            obj.lblCertificateName.text = (dic["name"] as! String)
            obj.lblDescription.text = (dic["description"] as! String)
            obj.certificateSwitch.tag = (dic["doc_certificate_id"] as! Int)
            obj.imgCertificate.sd_setImage(with: URL(string: (dic["certificate"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
            if (dic["status"] as! Int) == 0
            {
                obj.certificateSwitch.isOn = false
            }
            else
            {
                obj.certificateSwitch.isOn = true
            }
            obj.certificateSwitch.layer.cornerRadius = obj.certificateSwitch.frame.height/2
        }
        else
        {
            let dic = certificatedata[indexPath.row] as! NSDictionary
            
            obj.lblCertificateName.text = (dic["name"] as! String)
            obj.lblDescription.text = (dic["description"] as! String)
            obj.certificateSwitch.tag = (dic["doc_certificate_id"] as! Int)
            obj.imgCertificate.sd_setImage(with: URL(string: (dic["certificate"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
            
            obj.certificateSwitch.isHidden = true
        }
        
        return obj
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let dic = certificatedata[indexPath.row] as! NSDictionary
        
        let obj = storyboard?.instantiateViewController(withIdentifier: "CertificateDetailVC") as! CertificateDetailVC
        
        obj.certidata = dic
        
        certititle = (dic["name"] as! String)
        certidisc = (dic["description"] as! String)
        
        navigationController?.pushViewController(obj, animated: true)
        
    }
    
    
    
    //------------------------------
    // MARK: User Defined Functions
    //------------------------------
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            certificates()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    //------------------------------
    // MARK: Button Actions
    //------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnAddTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "AddCertificateVC") as! AddCertificateVC
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    @IBAction func certificateVisibility(_ sender: UISwitch)
    {
        certificateId = sender.tag
        certificateVisibility()
    }
    
    
    
    //------------------------------
    // MARK: Web Services
    //------------------------------
    
    
    
//    http://35.187.227.141/api/doctor/certificates
    
//    "{
//    ""doc_id"":3
//}"
    
    
//    "{
//    ""msg"": ""1 certificates available"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""doc_certificate_id"": 1,
//    ""name"": ""Best Doctor"",
//    ""description"": ""Lorem Ipsum is simply dummy text of the printing and typesetting industry"",
//    ""certificate"": ""http://http://35.187.227.141/storage/uploads/certi_1540461622.jpg"",
//    ""status"": 1
//    }
//    ]
//}"
//
    
    
    func certificates()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId")] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/certificates" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("1 certificates available")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            
                            self.certificatedata = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblCertificate.reloadData()
                            SVProgressHUD.dismiss()
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
            
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    
//   http://35.187.227.141/api/doctor/certi_status
    
    
//    "{
//    ""doc_certificate_id"":1
//}"

    
//    "{
//    ""msg"": ""Success! Certificate visibility changed"",
//    ""status"": 1,
//    ""visibility"": 1
//}"
    
    
    
    
    
    
    func certificateVisibility()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId"),"patient_id" : UserDefaults.standard.integer(forKey: "userId"), "doc_certificate_id" : certificateId] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/certi_status" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Success! Certificate visibility changed")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            

                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    
    
    
    
    
    
    func patientidcertificates()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        
        let parameter = ["doc_id" : doctoridentification] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/certificates" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("1 certificates available")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            
                            self.certificatedata = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblCertificate.reloadData()
                            SVProgressHUD.dismiss()
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
            
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
}
