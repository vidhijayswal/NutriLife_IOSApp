//
//  MNTForm2VC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 31/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class MNTForm2VC: UIViewController, UITextFieldDelegate
{
    
    //----------------------------
    // MARK: Outlets
    //----------------------------
    
    @IBOutlet weak var txtDailySchedule: UITextView!
    
    @IBOutlet weak var lblDailyScheduleError: UILabel!
    
    @IBOutlet weak var txtOccupation: UITextField!
    
    @IBOutlet weak var lblOccupationError: UILabel!
    
    @IBOutlet weak var txtIncome: UITextField!
    
    @IBOutlet weak var lblIncomeError: UILabel!
    
    @IBOutlet weak var txtFoodExpenditure: UITextField!
    
    @IBOutlet weak var lblFoodExpenditureError: UILabel!
    
    @IBOutlet weak var txtSpecialRequest: UITextView!
    
    @IBOutlet weak var lblSpecialRequestError: UILabel!
    //----------------------------
    // MARK: Identifiers
    //----------------------------
    
    
    
    //----------------------------
    // MARK: View Life Cycle
    //----------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        lblDailyScheduleError.isHidden = true
        lblOccupationError.isHidden = true
        lblIncomeError.isHidden = true
        lblFoodExpenditureError.isHidden = true
        lblSpecialRequestError.isHidden = true

        txtDailySchedule.layer.borderColor = UIColor.lightGray.cgColor
        txtDailySchedule.layer.borderWidth = 1
        txtSpecialRequest.layer.borderWidth = 1
        txtSpecialRequest.layer.borderColor = UIColor.lightGray.cgColor
        
        txtOccupation.delegate = self
        txtIncome.delegate = self
        txtFoodExpenditure.delegate = self
        
        txtOccupation.addTarget(self, action: #selector(txtOccupationValueChange), for: .editingChanged)
        txtIncome.addTarget(self, action: #selector(txtIncomeValueChange), for: .editingChanged)
        txtFoodExpenditure.addTarget(self, action: #selector(txtFoodExpenditureValueChange), for: .editingChanged)
        // Do any additional setup after loading the view.
    }
    

    //----------------------------
    // MARK: Delegate Methods
    //----------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    
    //----------------------------
    // MARK: User Defined Function
    //----------------------------
    
    @objc func txtOccupationValueChange()
    {
        if txtOccupation.text == ""
        {
            lblOccupationError.isHidden = false
        }
        else
        {
            lblOccupationError.isHidden = true
        }
    }
    @objc func txtIncomeValueChange()
    {
        if txtIncome.text == ""
        {
            lblIncomeError.isHidden = false
        }
        else
        {
            lblIncomeError.isHidden = true
        }
    }
    @objc func txtFoodExpenditureValueChange()
    {
        if txtFoodExpenditure.text == ""
        {
            lblFoodExpenditureError.isHidden = false
        }
        else
        {
            lblFoodExpenditureError.isHidden = true
        }
    }
    
    //----------------------------
    // MARK: Button Actions
    //----------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
   
    @IBAction func btnSubmitTUI(_ sender: UIButton)
    {
        if txtDailySchedule.text! == ""
        {
            lblDailyScheduleError.isHidden = false
        }
        else if txtOccupation.text! == ""
        {
            lblOccupationError.isHidden = false
        }
        else if txtIncome.text! == ""
        {
            lblIncomeError.isHidden = false
        }
        else if txtFoodExpenditure.text! == ""
        {
            lblFoodExpenditureError.isHidden = false
        }
        else
        {
            PopUp(Controller: self, title: "Message", message: "Your nutrition assessment form has been submitted and a request has been sent to the doctor.")
           
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1)
        {
          self.navigationController?.popToRootViewController(animated: true)
        }
       
        
    }
    
    
    //----------------------------
    // MARK: Web Services
    //----------------------------
    
    
    

}
