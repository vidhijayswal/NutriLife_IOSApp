//
//  tblCellSearchDoctor.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 30/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class tblCellSearchDoctor: UITableViewCell
{
    
    //---------------------------------
    // MARK: Outlets
    //---------------------------------
    
    @IBOutlet weak var imgDoctor: UIImageView!
    
    @IBOutlet weak var lblDoctorAddress: UILabel!
    
    @IBOutlet weak var lblDoctorName: UILabel!
    
    @IBOutlet weak var lblPackageDetails: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
