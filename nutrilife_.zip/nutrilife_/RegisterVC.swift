//
//  RegisterVC.swift
//  NutriLife
//

import UIKit
import Alamofire
import SVProgressHUD
import CoreLocation
import GoogleMaps
import GooglePlaces

class RegisterVC: UIViewController,UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource
{
    
    //------------------------------
    // MARK: Outlets
    //------------------------------
    
    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var lblFirstNameError: UILabel!
    
    @IBOutlet weak var lblFirstNamePlaceholder: UILabel!
    
    @IBOutlet weak var txtLastName: UITextField!
    
    @IBOutlet weak var lblLastNameError: UILabel!
    
    @IBOutlet weak var lblLastNamePlaceholder: UILabel!
    
    @IBOutlet weak var txtEmailID: UITextField!
    
    @IBOutlet weak var lblEmailIDError: UILabel!
    
    @IBOutlet weak var lblEmailIDPlaceholder: UILabel!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var lblPasswordError: UILabel!
    
    @IBOutlet weak var lblPasswordPlaceholder: UILabel!
    
    @IBOutlet weak var txtLocation: UITextField!
    
    @IBOutlet weak var lblLocationError: UILabel!
    
    @IBOutlet weak var lblLocationPlaceholder: UILabel!
    
    @IBOutlet weak var txtDOB: UITextField!
    
    @IBOutlet weak var lblDOBError: UILabel!
    
    @IBOutlet weak var lblDOBPlaceholder: UILabel!
    
    @IBOutlet weak var btnCheckbox: UIButton!
    
    @IBOutlet weak var btnHideDatePicker: UIButton!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    @IBOutlet weak var btnDOB: UIButton!
    
    @IBOutlet weak var registerScrollView: UIScrollView!
    
    @IBOutlet weak var tblLocationSearch: UITableView!
    
    //------------------------------
    // MARK: Identifiers
    //------------------------------
    
    var role = Int()
    var subRole = Int()
    var timer = Timer()
    var locationData = NSMutableArray()
    var placeId = String()
    var termsStatus = Int()
    
    //------------------------------
    // MARK: View Life Cycle
    //------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()

        lblFirstNameError.isHidden = true
        lblFirstNamePlaceholder.isHidden = true
        lblLastNameError.isHidden = true
        lblLastNamePlaceholder.isHidden = true
        lblEmailIDError.isHidden = true
        lblEmailIDPlaceholder.isHidden = true
        lblPasswordError.isHidden = true
        lblPasswordPlaceholder.isHidden = true
        lblLocationError.isHidden = true
        lblLocationPlaceholder.isHidden = true
        lblDOBError.isHidden = true
        lblDOBPlaceholder.isHidden = true
        btnHideDatePicker.isHidden = true
        datePicker.isHidden = true
        datePicker.backgroundColor = .white
        datePicker.datePickerMode = .date
        
        txtFirstName.delegate = self
        txtLastName.delegate = self
        txtEmailID.delegate = self
        txtPassword.delegate = self
        txtLocation.delegate = self
        
        tblLocationSearch.isHidden = true
        
        txtFirstName.addTarget(self, action: #selector(txtFirstNameValueChange), for: .editingChanged)
        txtLastName.addTarget(self, action: #selector(txtLastNameValueChange), for: .editingChanged)
        txtPassword.addTarget(self, action: #selector(txtPasswordValueChange), for: .editingChanged)
        txtEmailID.addTarget(self, action: #selector(txtEmailIdValueChange), for: .editingChanged)
        txtLocation.addTarget(self, action: #selector(txtLocationValueChange), for: .editingChanged)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name:UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name:UIResponder.keyboardWillHideNotification, object: nil)

    }
    

    //------------------------------
    // MARK: Delegate Methods
    //------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        self.view.endEditing(true)
        return true
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return locationData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let obj = tblLocationSearch.dequeueReusableCell(withIdentifier: "tblCellLocationSearch") as! tblCellLocationSearch
        let dic = locationData[indexPath.row] as! NSDictionary
        obj.lblLocation.text = (dic["description"] as! String)
        return obj
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dic = locationData[indexPath.row] as! NSDictionary
        let AddressDic = (dic["structured_formatting"] as! NSDictionary)
        txtLocation.text = (AddressDic["main_text"] as! String)
        //addressLine2String = (dic["description"] as! String)
        placeId = (dic["place_id"] as! String)
        tblLocationSearch.isHidden = true
    }
    
    //------------------------------
    // MARK: User Defined Functions
    //------------------------------
    
    @objc func txtFirstNameValueChange()
    {
        if txtFirstName.text == ""
        {
            lblFirstNamePlaceholder.isHidden = true
            lblFirstNameError.isHidden = false
        }
        else
        {
            lblFirstNamePlaceholder.isHidden = false
            lblFirstNameError.isHidden = true
        }
        
        
    }
    
    @objc func txtLastNameValueChange()
    {
        if txtLastName.text == ""
        {
            lblLastNamePlaceholder.isHidden = true
            lblLastNameError.isHidden = false
        }
        else
        {
            lblLastNamePlaceholder.isHidden = false
            lblLastNameError.isHidden = true
        }
        
    }
    
    
    @objc func txtEmailIdValueChange()
    {
        if txtEmailID.text == ""
        {
            lblEmailIDPlaceholder.isHidden = true
            lblEmailIDError.isHidden = false
        }
        else
        {
            lblEmailIDPlaceholder.isHidden = false
            lblEmailIDError.isHidden = true
        }
    }
    
    
    @objc func txtPasswordValueChange()
    {
        if txtPassword.text == ""
        {
            lblPasswordPlaceholder.isHidden = true
            lblPasswordError.isHidden = false
        }
        else
        {
            lblPasswordPlaceholder.isHidden = false
            lblPasswordError.isHidden = true
        }
    }
    @objc func txtLocationValueChange()
    {
        if txtLocation.text == ""
        {
            tblLocationSearch.isHidden = true
            lblLocationPlaceholder.isHidden = true
            lblLocationError.isHidden = false
        }
        else
        {
            addressLine2API(text: txtLocation.text!.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)
            lblLocationPlaceholder.isHidden = false
            lblLocationError.isHidden = true
        }
    }

    @objc func txtDOBValueChange()
    {
        if txtDOB.text == ""
        {
            lblDOBPlaceholder.isHidden = true
            lblDOBError.isHidden = false
        }
        else
        {
            lblDOBPlaceholder.isHidden = false
            lblDOBError.isHidden = true
        }
    }
    
    @objc func keyboardWillShow(notification:NSNotification)
    {
        var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.registerScrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height
        registerScrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification)
    {
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        registerScrollView.contentInset = contentInset
    }
    
    @objc func LocationSearchINChk()
    {
        if Connectivity.isConnectedToInternet()
        {
            addressLine2API(text: txtLocation.text!.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)
            SVProgressHUD.show()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            registerAPI()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    //------------------------------
    // MARK: Button Actions
    //------------------------------
    
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func btnHideDatePickerTUI(_ sender: UIButton)
    {
        let component = Calendar.current.dateComponents([.day,.month,.year], from: datePicker.date)
        txtDOB.text = String(describing: component.day!) + " - " + String(describing: component.month!) + " - " + String(describing: component.year!)
        btnHideDatePicker.isHidden = true
        datePicker.isHidden = true
    }
    
    
    @IBAction func btnDOBTUI(_ sender: UIButton)
    {
        self.view.endEditing(true)
        btnHideDatePicker.isHidden = false
        datePicker.isHidden = false
    }
    
    @IBAction func btnCheckboxTUI(_ sender: UIButton)
    {
        if btnCheckbox.isSelected
        {
            btnCheckbox.isSelected = false
        }
        else
        {
            btnCheckbox.isSelected = true
        }
    }
    
    @IBAction func btnRegisterTUI(_ sender: UIButton)
    {
        if txtFirstName.text == "" || (txtFirstName.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
        {
            lblFirstNameError.isHidden = false
        }
        else if txtLastName.text == "" || (txtLastName.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
        {
            lblLastNameError.isHidden = false
        }
            
        else if txtEmailID.text == "" || (txtEmailID.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
        {
            lblEmailIDError.isHidden = false
        }
        else if validateEmailWithString(txtEmailID.text! as NSString)
        {
            lblEmailIDError.text = "Enter valid Email ID"
            lblEmailIDError.isHidden = false
        }
            
        
        
        else if txtPassword.text == "" || (txtPassword.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
        {
            lblPasswordError.isHidden = false
        }
            
        else if txtLocation.text == "" || (txtLocation.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
        {
            lblLocationError.isHidden = false
        }
        else if txtDOB.text == "" || (txtDOB.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
        {
            lblDOBError.isHidden = false
        }
       else  if !btnCheckbox.isSelected
        {
            PopUp(Controller: self, title: "Error!", message: "Please accept terms and conditions")
            
        }
//        else
//        {
//            self.view.endEditing(true)
//            //latLongFromAdd(text: placeId)
//        }
        else
        {
            registerAPI()
        }
    }
    
    
    //------------------------------
    // MARK: Web Services
    //------------------------------

    func registerAPI()
    {

        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["fname": txtFirstName.text!, "lname": txtLastName.text!, "email": txtEmailID.text!, "password": txtPassword.text!,"role": role, "subrole": subRole, "dob": txtDOB.text!,"address": txtLocation.text! ,"latitude": location.coordinate.latitude,"longitude": location.coordinate.longitude] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "register" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Validation Successful")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                                self.VerifyEmail()

                        }


                    case .failure(let error):
                        print(error)
                    }
            }

        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }


    }
    func VerifyEmail()
    {

        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["email": txtEmailID.text!] as [String : Any]
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            Alamofire.request( appDelegate.apiString + "verifyemail", method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Validation Successful")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            SVProgressHUD.dismiss()
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))

                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                            

                            let obj = self.storyboard?.instantiateViewController(withIdentifier: "EmailVerificationVC") as! EmailVerificationVC


                            obj.emailId = self.txtEmailID.text!

                            UserDefaults.standard.set((result["user_id"] as! Int), forKey: "userId")
                            obj.code = (result["code"] as! String)
                            self.navigationController?.pushViewController(obj, animated: true)

                        }


                    case .failure(let error):
                        print(error)
                    }
            }

        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }


    }

    func addressLine2API(text: String)
    {
        
        
        
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            Alamofire.request( "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=" + text + "&types=establishment%7Cgeocode&radius=25000&language=en&key=AIzaSyAliEJ2-5R4_qpF0TyyIkLdcDDfNNgj-f8", method: .get , parameters: nil, encoding: JSONEncoding.default, headers: nil).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Validation Successful")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! String) == "OK"
                        {
                            self.locationData = (result["predictions"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblLocationSearch.isHidden = false
                            self.tblLocationSearch.reloadData()
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            
                            self.tblLocationSearch.isHidden = true
                            SVProgressHUD.dismiss()
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.LocationSearchINChk), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    func latLongFromAdd(text: String)
    {



        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            Alamofire.request( "https://maps.googleapis.com/maps/api/place/details/json?placeid="+text+"&key=AIzaSyAliEJ2-5R4_qpF0TyyIkLdcDDfNNgj-f8", method: .get , parameters: nil, encoding: JSONEncoding.default, headers: nil).validate(statusCode: 200..<500).responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Validation Successful")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! String) == "OK"
                        {
                            let dic1 = (result["result"] as! NSDictionary)

                            let dic2 = dic1["geometry"] as! NSDictionary
                            let dic3 = dic2["location"] as! NSDictionary
                            location = CLLocation(latitude: CLLocationDegrees(dic3["lat"] as! Double), longitude: CLLocationDegrees(dic3["lng"] as! Double))
                            self.registerAPI()
                            SVProgressHUD.dismiss()

                        }
                        else
                        {

                            PopUp(Controller: self, title: "Error!!", message: "Enter Proper Address")
                            SVProgressHUD.dismiss()

                        }


                    case .failure(let error):
                        print(error)
                    }
            }

        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }

    
    }
    

}
