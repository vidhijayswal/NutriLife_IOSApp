//
//  ReviewsVC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 01/11/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class ReviewsVC: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    
    
    
    //--------------------------------
    // MARK: Outlets
    //--------------------------------
    
    @IBOutlet weak var tblReviews: UITableView!
    
    @IBOutlet weak var btnWriteReview: UIButton!
    
    //--------------------------------
    // MARK: Identifiers
    //--------------------------------
    
    var reviewData = ["Good", "Average", "Very Good"]
    
    //--------------------------------
    // MARK: View Life Cycle
    //--------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()

        if UserDefaults.standard.string(forKey: "userType") == "Doctor"
        {
            btnWriteReview.isHidden = true
        }
        else
        {
            btnWriteReview.isHidden = false
        }
        // Do any additional setup after loading the view.
    }
    

    //--------------------------------
    // MARK: Delegate Methods
    //--------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return reviewData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let obj = tblReviews.dequeueReusableCell(withIdentifier: "tblCellReviews") as! tblCellReviews
        
        obj.lblReviewTitle.text = reviewData[indexPath.row]
        obj.lblDescription.text = "Review Description"
        
        return obj
    }
    
    //--------------------------------
    // MARK: User Defined Functions
    //--------------------------------
    
    
    
    //--------------------------------
    // MARK: Button Actions
    //--------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    //--------------------------------
    // MARK: Web Services
    //--------------------------------

}
