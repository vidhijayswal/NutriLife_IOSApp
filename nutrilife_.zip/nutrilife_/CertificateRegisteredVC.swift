//
//  CertificateRegisteredVC.swift
//  nutrilife_
//
//  Created by vidhi jayswal on 02/03/19.
//  Copyright © 2019 vidhi jayswal. All rights reserved.
//

import UIKit

class CertificateRegisteredVC: UIViewController
{

    
    @IBOutlet weak var lblLabel: UILabel!
    
    
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

    }

    @IBAction func btnClick(_ sender: Any)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        
        navigationController?.pushViewController(obj, animated: true)
        
    }
    
}
