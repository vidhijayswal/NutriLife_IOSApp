//
//  EditProfileVC.swift
//  Alamofire
//
//  Created by vidhi jayswal on 07/03/19.
//

import UIKit
import Alamofire
import SVProgressHUD
import SDWebImage
import CoreLocation
import GoogleMaps
import GooglePlaces

class EditProfileVC: UIViewController, UITextFieldDelegate
{

    @IBOutlet weak var imgUserImage: UIImageView!
    
    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var txtLastName: UITextField!
    
    @IBOutlet weak var txtEmailID: UITextField!
    
    @IBOutlet weak var txtLocation: UITextField!
    
    @IBOutlet weak var txtDateOfBirth: UITextField!
    
    @IBOutlet weak var lblFirstNameError: UILabel!
    
    @IBOutlet weak var lblLastNameError: UILabel!
    
    @IBOutlet weak var lblEmailIdError: UILabel!
    
    @IBOutlet weak var lblLocationError: UILabel!
    
    @IBOutlet weak var lblDobError: UILabel!
    
    
    
    var timer = Timer()
    
    var profileData =  NSDictionary()
    var patientprofile = NSDictionary()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        txtFirstName.delegate = self
        txtLastName.delegate = self
        txtEmailID.delegate = self
        txtDateOfBirth.delegate = self
        txtLocation.delegate = self
        
        lblFirstNameError.isHidden = true
        lblLastNameError.isHidden = true
        lblLocationError.isHidden = true
        lblEmailIdError.isHidden = true
        lblLocationError.isHidden = true
        lblDobError.isHidden = true
        
        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            txtFirstName.text = (profileData["fname"] as! String)
            txtLastName.text = (profileData["lname"] as! String)
            txtEmailID.text = (profileData["email"] as! String)
            txtLocation.text = (profileData["address"] as! String)
            txtDateOfBirth.text = (profileData["dob"] as! String)
            imgUserImage.sd_setImage(with: URL(string: (profileData["image"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
        }
        else
        {
            txtFirstName.text = (patientprofile["fname"] as! String)
            txtLastName.text = (patientprofile["lname"] as! String)
            txtEmailID.text = (patientprofile["email"] as! String)
            txtLocation.text = (patientprofile["address"] as! String)
            txtDateOfBirth.text = (patientprofile["dob"] as! String)
            imgUserImage.sd_setImage(with: URL(string: (patientprofile["image"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
            
        }
        
        
        
        
        txtFirstName.addTarget(self, action: #selector(txtFirstNameValueChanged), for: .editingChanged)
        txtLastName.addTarget(self, action: #selector(txtLastNameValueChanged), for: .editingChanged)
        txtLocation.addTarget(self, action: #selector(txtLocationValueChanged), for: .editingChanged)
        
        txtDateOfBirth.addTarget(self, action: #selector(txtDateOfBirthValueChanged), for: .editingChanged)
        txtEmailID.addTarget(self, action: #selector(txtEmailIdValueChanged), for: .editingChanged)
        

        
    }
    
    
    
    //--------------------------------
    // MARK: Delegate Methods
    //--------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        self.view.endEditing(true)
        return true
    }
    
    
    
    //--------------------------------
    // MARK: User Defined Functions
    //--------------------------------
    
    @objc func txtFirstNameValueChanged()
    {
        if txtFirstName.text == ""
        {
            lblFirstNameError.isHidden = false
        }
        else
        {
            lblFirstNameError.isHidden = true
        }
    }
    
    @objc func txtLastNameValueChanged()
    {
        if txtLastName.text == ""
        {
            lblLastNameError.isHidden = false
        }
        else
        {
            lblLastNameError.isHidden = true
        }
    }
    
    @objc func txtLocationValueChanged()
    {
        if txtLocation.text == ""
        {
            lblLocationError.isHidden = false
        }
        else
        {
            lblLocationError.isHidden = true
        }
    }
    
    
    @objc func txtDateOfBirthValueChanged()
    {
        if txtDateOfBirth.text == ""
        {
            lblDobError.isHidden = false
        }
        else
        {
            lblDobError.isHidden = true
        }
    }
    
    
    @objc func txtEmailIdValueChanged()
    {
        if txtEmailID.text == ""
        {
            lblEmailIdError.isHidden = false
        }
        else
        {
            lblEmailIdError.isHidden = true
        }
    }
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            editprofile()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
   
    
    //--------------------------------
    // MARK: Button Actions
    //--------------------------------
    
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    

    @IBAction func btnUpdateTUI(_ sender: UIButton)
    {
        if txtFirstName.text! == ""
        {
            lblFirstNameError.isHidden = false
        }
        else if txtLastName.text! == ""
        {
            lblLastNameError.isHidden = false
        }
        else if txtEmailID.text! == ""
        {
            lblEmailIdError.isHidden = false
        }
        else if txtLocation.text! == ""
        {
            lblLocationError.isHidden = false
        }
        else if txtDateOfBirth.text! == ""
        {
            lblDobError.isHidden = false
        }
        else
        {
            if UserDefaults.standard.string(forKey: "userrole") == "doctor"
            {
                editprofile()
                navigationController?.popViewController(animated: true)
            }
            else
            {
                editprofilepatient()
                navigationController?.popViewController(animated: true)
            }
        }
        
    }
    

    
    //--------------------------------
    // MARK: Web Services
    //--------------------------------
    
    
    
    
    //    http://35.187.227.141/api/doctor/editdoctor
    
    
    //    "{
    //    ""doc_id"":3,
    //    ""fname"":""Shreeraj"",
    //    ""lname"":""Jadeja"",
    //    ""image"":Upload file,
    //    ""address"":""Ahmedabad"",
    //    ""latitude"":""23.0171"",
    //    ""longitude"":""72.5172""
    //}"
    //
    
    
    
    //    "{
    //    ""msg"": ""Your profile successfully updated"",
    //    ""status"": 1
    //}"
    
    
    
    
    func editprofile()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId"), "fname": txtFirstName.text!, "lname": txtLastName.text!, "address": txtLocation.text!, "image": "http://35.187.227.141/nutrilife/storage/uploads/fileavatar_1550047076.jpg", "latitude": location.coordinate.latitude,"longitude": location.coordinate.longitude, "dob": txtDateOfBirth.text! ] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/editdoctor" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Your profile is successfully updated")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()

                            PopUp(Controller: self, title: "Message", message: (result["msg"] as! String))
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
  
    
    
    
    
    
    
    
    
    //Patient side edit profile API
    
    
//    http://35.187.227.141/api/patient/editpatient
    
    
    
    
//    "{
//    ""patient_id"":4,
//    ""fname"":""Sulay"",
//    ""lname"":""Panchal"",
//    ""image"":Upload file,
//    ""address"":""Ahmedabad"",
//    ""latitude"":""23.0171"",
//    ""longitude"":""72.5172""
//}"
    
    
    
    
    
//    "{
//    ""msg"": ""Your profile successfully updated"",
//    ""status"": 1
//}"
    
    
    
    
  
    
    func editprofilepatient()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["patient_id" : UserDefaults.standard.integer(forKey: "userId"), "fname": txtFirstName.text!, "lname": txtLastName.text!, "address": txtLocation.text!, "image": "http://35.187.227.141/nutrilife/storage/uploads/fileavatar_1550047076.jpg", "latitude": location.coordinate.latitude,"longitude": location.coordinate.longitude, "dob": txtDateOfBirth.text! ] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "patient/editpatient" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Your profile is successfully updated")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                            PopUp(Controller: self, title: "Message", message: (result["msg"] as! String))
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
}
