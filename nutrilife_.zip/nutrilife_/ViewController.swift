//
//  ViewController.swift
//  nutrilife_
//
//  Created by vidhi jayswal on 25/02/19.
//  Copyright © 2019 vidhi jayswal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

