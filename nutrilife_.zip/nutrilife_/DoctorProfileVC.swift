//
//  DoctorProfileVC.swift
//  NutriLife
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD
import HCSStarRatingView
import SDWebImage
import CoreLocation
import GoogleMaps
import GooglePlaces

class DoctorProfileVC: UIViewController, UITextFieldDelegate
{
    
    //--------------------------------
    // MARK: Outlets
    //--------------------------------
    
    @IBOutlet weak var imgUser: UIImageView!
    
    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var txtLastName: UITextField!
    
    @IBOutlet weak var ratingsStar: HCSStarRatingView!
    
    @IBOutlet weak var txtLocation: UITextField!
    
    @IBOutlet weak var availableSwitch: UISwitch!
    
    @IBOutlet weak var lblDOB: UILabel!
    
    @IBOutlet weak var lblEmail: UILabel!
    
    @IBOutlet weak var btnEdit: UIButton!
    
    @IBOutlet weak var btnCertificate: UIButton!
    
    @IBOutlet weak var btnReview: UIButton!
    
    //--------------------------------
    // MARK: Identifiers
    //--------------------------------
    
    var timer = Timer()
    
    var profileData =  NSDictionary()
    //--------------------------------
    // MARK: View Life Cycle
    //--------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
        
        availableSwitch.layer.cornerRadius = availableSwitch.frame.height/2
        viewprofile()
        txtLocation.delegate = self
        txtFirstName.delegate = self
        txtLastName.delegate = self
        txtFirstName.isEnabled = false
        txtLastName.isEnabled = false
        txtLocation.isEnabled = false
        
        imgUser.layer.cornerRadius = imgUser.frame.size.width / 2
        imgUser.clipsToBounds = true
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        viewprofile()
    }
    

    //--------------------------------
    // MARK: Delegate Methods
    //--------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        self.view.endEditing(true)
        return true
    }
    
    
    //--------------------------------
    // MARK: User Defined Functions
    //--------------------------------
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            viewprofile()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet is Not Available")
        }
    }
    
    
    //--------------------------------
    // MARK: Button Actions
    //--------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnCertificateTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "CertificateVC") as! CertificateVC
        navigationController?.pushViewController(obj, animated: true)
    }
    
    @IBAction func btnReviewTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "ReviewsVC") as! ReviewsVC
        navigationController?.pushViewController(obj, animated: true)
    }

    
    @IBAction func btnEditTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "EditProfileVC") as! EditProfileVC
        
        obj.profileData = self.profileData
        
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    @IBAction func switchAvailableDoctor(_ sender: UISwitch)
    {
        doctoravailable()
    }
    
    @IBAction func btnChangePassword(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "ChangePasswordVC") as! ChangePasswordVC
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    
    
    //--------------------------------
    // MARK: Web Services
    //--------------------------------
    
    
    
//    http://35.187.227.141/api/doctor/profile
    
    
//    "{
//    ""doc_id"":3
//}"

//    "{
//    ""msg"": ""Doctor's profile details"",
//    ""status"": 1,
//    ""data"": {
//    ""fname"": ""Shreeraj"",
//    ""lname"": ""Jadeja"",
//    ""image"": ""http://http://35.187.227.141/storage/uploads/sgm2_1540893810.png"",
//    ""email"": ""shreeraj.qrioustech@gmail.com"",
//    ""availability"": 1,
//    ""dob"": ""1993-04-17"",
//    ""address"": ""Ahmedabad"",
//    ""reviews"": 1,
//    ""certificates"": 1
//    }
//}"

    
    
    func viewprofile()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId")  ] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/profile" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Doctor's profile details")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                            
                            let data = result["data"] as! NSDictionary
                            self.profileData = result["data"] as! NSDictionary
                            self.imgUser.sd_setImage(with: URL(string: (data["image"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
                            
                            
                            self.txtFirstName.text = (data["fname"] as! String)
                            self.txtLastName.text = (data["lname"] as! String)
                            
                            self.txtLocation.text = (data["address"] as! String)
                            
                           // self.availableSwitch.isOn = (data["availability"] as! Int)
                            
                            
                            self.lblDOB.text = "DOB: "+((data["dob"] as! String))
                            
                            self.lblEmail.text = "Email: "+(data["email"] as! String)
                            
                            self.ratingsStar.value = CGFloat((data["reviews"] as! Int))
                            
                            
                            if (data["availability"] as! Int) == 0
                            {
                                self.availableSwitch.isOn = false
                            }
                            else
                            {
                                self.availableSwitch.isOn = true
                            }
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    
    
    
    
    
//    http://35.187.227.141/api/doctor/doc_status
    
    
//    "{
//    ""doc_id"":3
//}"

    
    
//    "{
//    ""msg"": ""Doctor available"",
//    ""status"": 1,
//    ""availability"": 1
//}"
    
    
    
    
    func doctoravailable()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId")  ] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/doc_status" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Doctor available")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
}
