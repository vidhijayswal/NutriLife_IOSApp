//
//  EmailVerificationVC.swift
//  NutriLife
//
//

import UIKit
import Alamofire
import SVProgressHUD

class EmailVerificationVC: UIViewController, UITextFieldDelegate
{
    
    //--------------------------------------
    // MARK: Outlets
    //--------------------------------------
    
    @IBOutlet weak var lblCodePlaceholder: UILabel!
    
    @IBOutlet weak var txtCode: UITextField!
    
    @IBOutlet weak var lblCodeError: UILabel!
    
    //--------------------------------------
    // MARK: Identifiers
    //--------------------------------------
    
    var emailId = String()
    var code = String()
    var timer = Timer()
    //--------------------------------------
    // MARK: View Life Cycle
    //--------------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()

        txtCode.delegate = self
        txtCode.addTarget(self, action: #selector(txtCodeValueChange), for: .editingChanged)
        
    }
    

    //--------------------------------------
    // MARK: Delegate Methods
    //--------------------------------------
    
    
    //--------------------------------------
    // MARK: User Defined Function
    //--------------------------------------
    
    @objc func txtCodeValueChange()
    {
        if txtCode.text == ""
        {
            lblCodeError.isHidden = false
            lblCodePlaceholder.isHidden = true
        }
        else
        {
            lblCodePlaceholder.isHidden = false
            lblCodeError.isHidden = true
        }
    }
    
    //--------------------------------------
    // MARK: Button Actions
    //--------------------------------------
    
    @IBAction func btnVerifyTUI(_ sender: UIButton)
    {
        if txtCode.text == "" || (txtCode.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
        {
            lblCodeError.isHidden = false
        }
        
        else
        {
            if txtCode.text == code
            {
                verifycode()
            }
            else
            {
                PopUp(Controller: self, title: "Error!", message: "Code is incorrect")
            }
            
        }
        
    }
    
    
    //--------------------------------------
    // MARK: Web Services
    //--------------------------------------

    func verifycode()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["user_id" : UserDefaults.standard.integer(forKey: "userId")] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "verifycode" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Validation Successful")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                            let obj = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                        self.navigationController?.pushViewController(obj, animated: true)
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            verifycode()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
}
