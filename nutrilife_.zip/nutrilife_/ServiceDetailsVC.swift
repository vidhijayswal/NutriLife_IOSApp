//
//  ServiceDetailsVC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 01/11/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD

class ServiceDetailsVC: UIViewController
{
    
    //----------------------------------
    // MARK: Outlets
    //----------------------------------

    @IBOutlet weak var lblServiceName: UILabel!
    
    @IBOutlet weak var lblStatus: UILabel!
    
    @IBOutlet weak var lblDoctorName: UILabel!
    
    @IBOutlet weak var imgDoctor: UIImageView!
    
    @IBOutlet weak var lblDoctorAddress: UILabel!
    
    @IBOutlet weak var lblPackageName: UILabel!
    
    @IBOutlet weak var lblPackagePrice: UILabel!
    
    @IBOutlet weak var containerView: UIView!
    
    
    
    //----------------------------------
    // MARK: Identifiers
    //----------------------------------
    
    var goalsVC = UIViewController()
    var servicedata = NSDictionary()
    
    //----------------------------------
    // MARK: View Life Cycle
    //----------------------------------
    override func viewDidLoad() {
        super.viewDidLoad()

        goalsVC = storyboard?.instantiateViewController(withIdentifier: "GoalsAndPaymentVC") as! GoalsAndPaymentVC
        currentVC = "Goals"
        self.addChild(goalsVC)
        goalsVC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
        self.containerView.addSubview(goalsVC.view)
        goalsVC.didMove(toParent: self)
        
        
        lblServiceName.text = (servicedata["service_name"] as! String)
        lblStatus.text = (servicedata["status"] as! String)
        lblDoctorName.text = (servicedata["doc_name"] as! String)
      
        lblDoctorAddress.isHidden = true
       
        lblPackageName.text = (servicedata["package_name"] as! String)
        lblPackagePrice.text = (servicedata["package_amount"] as! String)
        
    }
    
    
    //----------------------------------
    // MARK: Delegate Methods
    //----------------------------------
    
    
    
    //----------------------------------
    // MARK: User Defined Functions
    //----------------------------------
    
    
    
    //----------------------------------
    // MARK: Button Actions
    //----------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    
    //----------------------------------
    // MARK: Web Services
    //----------------------------------

}
