//
//  tblCellCertificate.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 01/11/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class tblCellCertificate: UITableViewCell
{
    
    //------------------------------
    // MARK: Outlets
    //------------------------------
    
    @IBOutlet weak var imgCertificate: UIImageView!
    
    @IBOutlet weak var lblCertificateName: UILabel!
    
    @IBOutlet weak var lblDescription: UILabel!
    
    @IBOutlet weak var certificateSwitch: UISwitch!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
