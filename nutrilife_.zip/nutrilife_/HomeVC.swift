//
//  HomeVC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 30/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class HomeVC: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    
    
    
    //-------------------------------
    // MARK: Outlets
    //-------------------------------
    
    @IBOutlet weak var imgHome: UIImageView!
    
    @IBOutlet weak var lblHome: UILabel!
    
    @IBOutlet weak var imgMessage: UIImageView!
    
    @IBOutlet weak var lblMessage: UILabel!
    
    @IBOutlet weak var imgNotification: UIImageView!
    
    @IBOutlet weak var lblNotification: UILabel!
    
    @IBOutlet weak var containerView: UIView!
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var tblDrawerMenu: UITableView!
    
    @IBOutlet weak var tblDrawerMenuWidth: NSLayoutConstraint!
    
    @IBOutlet weak var btnHideDrawerMenu: UIButton!
    //-------------------------------
    // MARK: Identifiers
    //-------------------------------
    
    var VC = UIViewController()
    var DrawerMenuPatient = ["Home","My Profile","My Doctor","My Payments","My Services","Videos", "Books","About NutriLife","Contact Us","Logout"]
    var DrawerMenuDoctor = ["My Profile","My Patients","My Wallet","My Services","My Videos", "My Books","About NutriLife","Contact Us","Logout"]
    
    //-------------------------------
    // MARK: View Life Cycle
    //-------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        
        UserDefaults.standard.synchronize()
        tblDrawerMenuWidth.constant = 0
        btnHideDrawerMenu.isHidden = true
        print(UserDefaults.standard.string(forKey: "userrole"))
        if UserDefaults.standard.string(forKey: "userrole")! == "doctor"
        {
            lblTitle.text = "Home"
            VC = storyboard?.instantiateViewController(withIdentifier: "DoctorHomeVC") as! DoctorHomeVC
            self.addChild(VC)
            VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
            self.containerView.addSubview(VC.view)
            VC.didMove(toParent: self)
        }
        else
        {
            VC = storyboard?.instantiateViewController(withIdentifier: "ServicesPatientSideVC") as! ServicesPatientSideVC
            self.addChild(VC)
            VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
            self.containerView.addSubview(VC.view)
            VC.didMove(toParent: self)
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(ChangeVC), name: Notification.Name("VcChanged"), object: nil)
        
    }
    
    //-------------------------------
    // MARK: Delegate Methods
    //-------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if UserDefaults.standard.string(forKey:"userrole") == "doctor"
        {
            return DrawerMenuDoctor.count
        }
        else
        {
            return DrawerMenuPatient.count
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let obj = tblDrawerMenu.dequeueReusableCell(withIdentifier: "tblCellDrawerMenu") as! tblCellDrawerMenu
        if UserDefaults.standard.string(forKey:"userrole") == "doctor"
        {
            obj.lblMenuItem.text = DrawerMenuDoctor[indexPath.row]
        }
        else
        {
            obj.lblMenuItem.text = DrawerMenuPatient[indexPath.row]
        }
        
        return obj
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        var str = String()
        if UserDefaults.standard.string(forKey:"userrole") == "doctor"
        {
            str = DrawerMenuDoctor[indexPath.row]
        }
        else
        {
            str = DrawerMenuPatient[indexPath.row]
        }
        switch str
        {
            
            
        case "Home":
            if UserDefaults.standard.string(forKey: "userrole") == "doctor"
            {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "VcChanged"), object: nil, userInfo: ["Id": "DoctorHomeVC"])
            }
            else
            {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "VcChanged"), object: nil, userInfo: ["Id": "ServicesPatientSideVC"])
            }
            btnHideDrawerMenu.isHidden = true
            
            UIView.animate(withDuration: 10.0, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: { () -> Void in
                self.tblDrawerMenuWidth.constant = 0
            }, completion: { (finished:Bool) -> Void in
                
            })
            
        
        case "My Profile":
            
            if UserDefaults.standard.string(forKey: "userrole") == "doctor"
            {
                let obj = storyboard?.instantiateViewController(withIdentifier: "DoctorProfileVC") as! DoctorProfileVC
                navigationController?.pushViewController(obj, animated: true)
            }
            else
            {
                let obj = storyboard?.instantiateViewController(withIdentifier: "PatientProfileVC") as! PatientProfileVC
                navigationController?.pushViewController(obj, animated: true)
            }
            
            btnHideDrawerMenu.isHidden = true
            
            UIView.animate(withDuration: 10.0, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: { () -> Void in
                self.tblDrawerMenuWidth.constant = 0
            }, completion: { (finished:Bool) -> Void in
                
            })
        
        case "My Doctor","My Patients":
            let obj = storyboard?.instantiateViewController(withIdentifier: "MyDoctorVC") as! MyDoctorVC
            navigationController?.pushViewController(obj, animated: true)
            
            btnHideDrawerMenu.isHidden = true
            
            UIView.animate(withDuration: 10.0, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: { () -> Void in
                self.tblDrawerMenuWidth.constant = 0
            }, completion: { (finished:Bool) -> Void in
                
            })
        case "My Payments","My Wallet":
            let obj = storyboard?.instantiateViewController(withIdentifier: "MyWalletVC") as! MyWalletVC
            navigationController?.pushViewController(obj, animated: true)
            
            btnHideDrawerMenu.isHidden = true
            
            UIView.animate(withDuration: 10.0, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: { () -> Void in
                self.tblDrawerMenuWidth.constant = 0
            }, completion: { (finished:Bool) -> Void in
                
            })
            
        case "My Services":
            if UserDefaults.standard.string(forKey: "userrole") == "doctor"
            {
                let obj = storyboard?.instantiateViewController(withIdentifier: "MyServicesDoctorVC") as! MyServicesDoctorVC
                navigationController?.pushViewController(obj, animated: true)
            }
            else
            {
                let obj = storyboard?.instantiateViewController(withIdentifier: "MyServicesVC") as! MyServicesVC
                navigationController?.pushViewController(obj, animated: true)
            }
            
            
            
            btnHideDrawerMenu.isHidden = true
            
            UIView.animate(withDuration: 10.0, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: { () -> Void in
                self.tblDrawerMenuWidth.constant = 0
            }, completion: { (finished:Bool) -> Void in
                
            })
            
        case "Videos","My Videos":
            let obj = storyboard?.instantiateViewController(withIdentifier: "VideosVC") as! VideosVC
            navigationController?.pushViewController(obj, animated: true)
            
            btnHideDrawerMenu.isHidden = true
            
            UIView.animate(withDuration: 10.0, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: { () -> Void in
                self.tblDrawerMenuWidth.constant = 0
            }, completion: { (finished:Bool) -> Void in
                
            })
            
        case "Books","My Books":
            let obj = storyboard?.instantiateViewController(withIdentifier: "BooksVC") as! BooksVC
            navigationController?.pushViewController(obj, animated: true)
            
            btnHideDrawerMenu.isHidden = true
            
            UIView.animate(withDuration: 10.0, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: { () -> Void in
                self.tblDrawerMenuWidth.constant = 0
            }, completion: { (finished:Bool) -> Void in
                
            })
        case "About NutriLife":
            let obj = storyboard?.instantiateViewController(withIdentifier: "AboutNutrilifeVC") as! AboutNutrilifeVC
            navigationController?.pushViewController(obj, animated: true)
            
            btnHideDrawerMenu.isHidden = true
            
            UIView.animate(withDuration: 10.0, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: { () -> Void in
                self.tblDrawerMenuWidth.constant = 0
            }, completion: { (finished:Bool) -> Void in
                
            })
        
        case "Contact Us":
            let obj = storyboard?.instantiateViewController(withIdentifier: "ContactUsVC") as! ContactUsVC
            navigationController?.pushViewController(obj, animated: true)
            
            btnHideDrawerMenu.isHidden = true
            
            UIView.animate(withDuration: 10.0, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: { () -> Void in
                self.tblDrawerMenuWidth.constant = 0
            }, completion: { (finished:Bool) -> Void in
                
            })
            
            
        case "Logout":
            
            //PopUp(Controller: self, title: "Alert", message: "Are you sure you want to logout?")
            
//            let alert = UIAlertController(title: "Alert", message: "Are you sure you want to logout?", preferredStyle: .alert)
//
//            alert.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
//
//            present(alert, animated: true, completion: nil)
            
            UserDefaults.standard.set("0", forKey: "isLogin")
            
            let obj = storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            
            navigationController?.pushViewController(obj, animated: true)
            
            
            
            
            
            
        default:
            print("No Option Selected")
        }
        
    }
    
    //-------------------------------
    // MARK: User Defined Function
    //-------------------------------
    
    @objc func ChangeVC(_notification: Notification)
    {
        VC.view.removeFromSuperview()
        
        switch (_notification.userInfo!["Id"] as! String)
        {
            
        case "DoctorHomeVC":
            lblTitle.text = "Home"
            VC = storyboard?.instantiateViewController(withIdentifier: "DoctorHomeVC") as! DoctorHomeVC
       
        case "ServicesPatientSideVC":
            lblTitle.text = "Services Available"
            VC = storyboard?.instantiateViewController(withIdentifier: "ServicesPatientSideVC") as! ServicesPatientSideVC
            
        case "MessageVC":
            lblTitle.text = "Messages"
            VC = storyboard?.instantiateViewController(withIdentifier: "MessageVC") as! MessageVC
        case "NotificationVC":
            VC = storyboard?.instantiateViewController(withIdentifier: "NotificationVC") as! NotificationVC
        default:
            print("")
        }
        self.addChild(VC)
        VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
        self.containerView.addSubview(VC.view)
        VC.didMove(toParent: self)
    }
    
    //-------------------------------
    // MARK: Button Actions
    //-------------------------------
    
    @IBAction func btnHomeTUI(_ sender: UIButton)
    {
        if imgHome.image == UIImage(named: "icon_home_gray")
        {
            if UserDefaults.standard.string(forKey: "userrole") == "doctor"
            {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "VcChanged"), object: nil, userInfo: ["Id": "DoctorHomeVC"])
            }
            else
            {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "VcChanged"), object: nil, userInfo: ["Id": "ServicesPatientSideVC"])
            }
            
            
            imgHome.image = UIImage(named: "icon_home_black")
            lblHome.textColor = UIColor.black
            imgMessage.image = UIImage(named: "icon_message_gray")
            lblMessage.textColor = UIColor(rgb: 0x999999)
            imgNotification.image = UIImage(named: "icon_notification_gray")
            lblNotification.textColor = UIColor(rgb: 0x999999)
        }
    }
    
    @IBAction func btnMessageTUI(_ sender: UIButton)
    {
        
        if imgMessage.image == UIImage(named: "icon_message_gray")
        {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "VcChanged"), object: nil, userInfo: ["Id": "MessageVC"])
            imgMessage.image = UIImage(named: "icon_message_black")
            lblMessage.textColor = UIColor.black
            imgHome.image = UIImage(named: "icon_home_gray")
            lblHome.textColor = UIColor(rgb: 0x999999)
            imgNotification.image = UIImage(named: "icon_notification_gray")
            lblNotification.textColor = UIColor(rgb: 0x999999)
        }
    }
    
    @IBAction func btnNotificationTUI(_ sender: UIButton)
    {
        if imgNotification.image == UIImage(named: "icon_notification_gray")
        {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "VcChanged"), object: nil, userInfo: ["Id": "NotificationVC"])
            imgNotification.image = UIImage(named: "icon_notification_black")
            lblNotification.textColor = UIColor.black
            imgHome.image = UIImage(named: "icon_home_gray")
            lblHome.textColor = UIColor(rgb: 0x999999)
            imgMessage.image = UIImage(named: "icon_message_gray")
            lblMessage.textColor = UIColor(rgb: 0x999999)
        }
    }
    @IBAction func btnDrawerMenuTUI(_ sender: UIButton)
    {
        btnHideDrawerMenu.isHidden = false
        UIView.animate(withDuration: 2.0, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: { () -> Void in
            if self.tblDrawerMenuWidth.constant == 0 {
                self.tblDrawerMenuWidth.constant = self.view.frame.width * 0.7
            }
            else {
                self.tblDrawerMenuWidth.constant = 0
            }
        }, completion: { (finished:Bool) -> Void in
            
        })
    }
    
    @IBAction func btnHideDrawerMenuTUI(_ sender: UIButton)
    {
        btnHideDrawerMenu.isHidden = true
        UIView.animate(withDuration: 10.0, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: { () -> Void in
            if self.tblDrawerMenuWidth.constant == 0 {
                self.tblDrawerMenuWidth.constant = self.view.frame.width * 0.7
            }
            else {
                self.tblDrawerMenuWidth.constant = 0
            }
        }, completion: { (finished:Bool) -> Void in
            
        })
    }
    //-------------------------------
    // MARK: Web Services
    //-------------------------------

}
