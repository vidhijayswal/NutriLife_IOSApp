//
//  AddPackageVC.swift
//  NutriLife
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD

class AddPackageVC: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    
    
    
    //------------------------------
    // MARK: Outlets
    //------------------------------
    
    @IBOutlet weak var tblPackages: UITableView!
    
    @IBOutlet weak var btnAdd: UIButton!
    
    
    
    //------------------------------
    // MARK: Identifiers
    //------------------------------
    
    var doctorPackageData = NSMutableArray()
    var timer = Timer()

    var serviceid1 = Int()
    
    //------------------------------
    // MARK: View Life Cycle
    //------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        viewpackage()
        
    }
    
    //------------------------------
    // MARK: Delegate Methods
    //------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return doctorPackageData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        
        
        //obj.lblServiceName.text = ServicesArr[indexPath.row]
//        obj.serviceSwitch.layer.cornerRadius = obj.serviceSwitch.frame.height/2
//        let dic = doctorServiceData[indexPath.row] as! NSDictionary
//        if (dic["status"] as! Int) == 0
//        {
//            obj.serviceSwitch.isOn = false
//        }
//        else
//        {
//            obj.serviceSwitch.isOn = true
//        }
//
//        obj.lblServiceName.text = (dic["service_name"] as! String)
//        obj.serviceSwitch.tag = (dic["service_id"] as! Int)
        
        
        
        let obj = tblPackages.dequeueReusableCell(withIdentifier: "tblCellAddPackage") as! tblCellAddPackage
        let dic = doctorPackageData[indexPath.row] as! NSDictionary
        
        
        obj.lblPackageName.text = (dic["package_name"] as! String)
        obj.lblServiceName.text = (dic["service_name"] as! String)
        obj.lblPrice.text = String(dic["package_amount"] as! Int)
        obj.lblDescription.text = (dic["package_description"] as! String)
        return obj
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
        let dic = doctorPackageData[indexPath.row] as! NSDictionary
    
        let obj = storyboard?.instantiateViewController(withIdentifier: "PackageDetailsVC") as! PackageDetailsVC
        obj.idservice = (dic["service_id"] as! Int)
        navigationController?.pushViewController(obj, animated: true)
    }
    
    //------------------------------
    // MARK: User Defined Function
    //------------------------------
    
        @objc func InternetAvailable()
        {
            if Connectivity.isConnectedToInternet()
            {
                viewpackage()
            }
            else
            {
                SVProgressHUD.dismiss()
                PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
            }
        }
    
    //------------------------------
    // MARK: Button Actions
    //------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnAddTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "AddPackageDetailsVC") as! AddPackageDetailsVC
        navigationController?.pushViewController(obj, animated: true)
    }
    //------------------------------
    // MARK: Web Services
    //------------------------------
    
    
//    http://35.187.227.141/api/doctor/packages
    
    
//    "{
//    ""doc_id"": 2,
//    ""service_id"": 1
//}"
    
    
//    "{
//    ""msg"": ""3 packages available"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""doc_id"": 2,
//    ""doc_name"": ""Shreeraj Jadeja"",
//    ""location"": ""Ahmedabad"",
//    ""service_id"": 1,
//    ""service_name"": ""Infants & Pediatric"",
//    ""package_id"": 1,
//    ""package_name"": ""Viral Disease"",
//    ""package_amount"": 200,
//    ""package_description"": ""This is Basic&nbsp;<br><b>Package including viral disease</b>""
//    },
//    {
//    ""doc_id"": 2,
//    ""doc_name"": ""Shreeraj Jadeja"",
//    ""location"": ""Ahmedabad"",
//    ""service_id"": 1,
//    ""service_name"": ""Infants & Pediatric"",
//    ""package_id"": 2,
//    ""package_name"": ""Skin Infections"",
//    ""package_amount"": 80,
//    ""package_description"": ""This is Basic package of add skin infections""
//    },
//    {
//    ""doc_id"": 2,
//    ""doc_name"": ""Shreeraj Jadeja"",
//    ""location"": ""Ahmedabad"",
//    ""service_id"": 1,
//    ""service_name"": ""Infants & Pediatric"",
//    ""package_id"": 3,
//    ""package_name"": ""Migrant"",
//    ""package_amount"": 300,
//    ""package_description"": ""Its contineus<br>&nbsp;headache usually for 17hours""
//    }
//    ]
//}"
    
    
    
        func viewpackage()
        {
            
            let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
            let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId"),"service_id" : serviceid] as [String : Any]
            print(parameter)
            if Connectivity.isConnectedToInternet()
            {
                timer.invalidate()
                SVProgressHUD.show()
                
                Alamofire.request( appDelegate.apiString + "doctor/packages" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                    {
                        response in
                        switch response.result
                        {
                        case .success:
                            let result = response.result.value! as! NSDictionary
                            print(result)
                            if (result["status"] as! Int) == 0
                            {
                                PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                                SVProgressHUD.dismiss()
                            }
                            else
                            {
                                self.doctorPackageData = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                                self.tblPackages.reloadData()
                                SVProgressHUD.dismiss()
                            }
                            
                            
                        case .failure(let error):
                            print(error)
                        }
                }
                
            }
            else
            {
                self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
                PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
            }
            
            
        }

}
