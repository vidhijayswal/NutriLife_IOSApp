//
//  DoctorHomeVC.swift
//  NutriLife
//
//  
//

import UIKit
import SVProgressHUD
import Alamofire

class DoctorHomeVC: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{
    
    
    
    //------------------------------
    // MARK: Outlets
    //------------------------------

    @IBOutlet weak var colDoctorHome: UICollectionView!
    
    //------------------------------
    // MARK: Identifiers
    //------------------------------
    
     var timer = Timer()
    
    var doctorHomeData = NSDictionary()
    
    var titleArr = ["Services", "Patients", "Packages", "Active Patients", "Total Earned","Completed Patient","Books","Videos"]
//    var countArr = ["4", "16", "1000$", "10", "2", "2", "9"]
    
    
    
    //------------------------------
    // MARK: View Life Cycle
    //------------------------------
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        homeAPI()

        // Do any additional setup after loading the view.
    }
    
    //------------------------------
    // MARK: Delegate Methods
    //------------------------------
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return doctorHomeData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let obj = colDoctorHome.dequeueReusableCell(withReuseIdentifier: "colCellDoctorHome" , for: indexPath) as! colCellDoctorHome
        obj.layer.borderWidth = 1
        obj.layer.borderColor = UIColor.lightGray.cgColor
        
        obj.lblTitle.text = titleArr[indexPath.row]
        if indexPath.row == 0
        {
            obj.lblCount.text = String(doctorHomeData["services"] as! Int)
        }
        
        else if indexPath.row == 1
        {
            obj.lblCount.text = String(doctorHomeData["patients"] as! Int)
        }
        
        else if indexPath.row == 2
        {
            obj.lblCount.text = String(doctorHomeData["packages"] as! Int)
        }
        
        else if indexPath.row == 3
        {
            obj.lblCount.text = String(doctorHomeData["active_patients"] as! Int)
        }
        
        else if indexPath.row == 4
        {
            obj.lblCount.text = String(doctorHomeData["total_earned"] as! Int)
        }

        else if indexPath.row == 5
        {
            obj.lblCount.text = String(doctorHomeData["completed_patients"] as! Int)
        }
        
        else if indexPath.row == 6
        {
            obj.lblCount.text = String(doctorHomeData["books"] as! Int)
        }
        else if indexPath.row == 7
        {
            obj.lblCount.text = String(doctorHomeData["videos"] as! Int)
        }

        return obj
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: colDoctorHome.frame.width/2 - 3, height: 90)
    }
    
    //------------------------------
    // MARK: User Defined Functions
    //------------------------------
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            homeAPI()
            
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    
    //------------------------------
    // MARK: Web Services
    //------------------------------
    
    
    
    //http://35.187.227.141/api/doctor/home
    
    
//    "{
//    ""doc_id"":3
//}"
    
    
    
    
//    "{
//    ""msg"": ""Doctor complete details"",
//    ""status"": 1,
//    ""data"": {
//    ""services"": 2,
//    ""patients"": 1,
//    ""packages"": 2,
//    ""active_patients"": 1,
//    ""completed_patients"": 0,
//    ""books"": 2,
//    ""videos"": 2
//    }
//}"
    
    func homeAPI()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId")] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/home" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Doctor complete details")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            self.doctorHomeData = result["data"] as! NSDictionary
                            self.colDoctorHome.reloadData()
                            SVProgressHUD.dismiss()
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    
    
    
}
