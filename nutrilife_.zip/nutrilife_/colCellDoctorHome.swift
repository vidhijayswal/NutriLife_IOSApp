//
//  colCellDoctorHome.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 01/11/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class colCellDoctorHome: UICollectionViewCell
{
    //------------------------------
    // MARK: Outlets
    //------------------------------
    
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var lblCount: UILabel!
    
}
