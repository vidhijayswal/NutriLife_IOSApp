//
//  DoctorDetailsVC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 30/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//


import UIKit
import Alamofire
import SVProgressHUD

class DoctorDetailsVC: UIViewController, UITableViewDelegate,UITableViewDataSource
{
    
    
    
    //--------------------------------
    // MARK: Outlets
    //--------------------------------
    
    @IBOutlet weak var imgDoctor: UIImageView!
    
    @IBOutlet weak var lblDoctorName: UILabel!
    
    @IBOutlet weak var lblDoctorAddress: UILabel!
    
    @IBOutlet weak var tblPackages: UITableView!
    
    @IBOutlet weak var lblTotalEarned: UILabel!
    
    @IBOutlet weak var lblTotalPatient: UILabel!
    
    @IBOutlet weak var tblPackagesHeight: NSLayoutConstraint!
    
    @IBOutlet weak var scrollingViewHeight: NSLayoutConstraint!
    //--------------------------------
    // MARK: Identifiers
    //--------------------------------
    
    var packageData = NSMutableArray()
    
    var doctordata = NSDictionary()
    
    var iddoc = Int()
    var timer = Timer()
    
    //--------------------------------
    // MARK: View Life Cycle
    //--------------------------------
    

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
        doctorpackage()
    }
    override func viewDidLayoutSubviews()
    {
        scrollingViewHeight.constant = 420 + tblPackages.contentSize.height
        tblPackagesHeight.constant = tblPackages.contentSize.height + 100
        
        tblPackages.reloadData()
    }
    
    //--------------------------------
    // MARK: Delegate Methods
    //--------------------------------

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return packageData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let obj = tblPackages.dequeueReusableCell(withIdentifier: "tblCellDoctorPackages") as! tblCellDoctorPackages
       let dic = packageData[indexPath.row] as! NSDictionary
        
        obj.packageView.layer.borderWidth = 1
        obj.packageView.layer.borderColor = UIColor.lightGray.cgColor
        
        
        
        
        obj.lblPackageName.text! = (dic["package_name"] as! String)
        obj.lblPackagePrice.text! = (dic["package_amount"] as! String)
        return obj
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "PackageDetailsVC") as! PackageDetailsVC
        
       // let dic = packageData[indexPath.row] as! NSDictionary

        obj.doctor_identification = iddoc
        obj.serviceid_patientside = serviceid

        navigationController?.pushViewController(obj, animated: true)
    }
    
    //--------------------------------
    // MARK: User Defined Functions
    //--------------------------------
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            doctorpackage()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    func fillData()
    {
        lblDoctorName.text! = (doctordata["name"] as! String)
        lblDoctorAddress.text! = (doctordata["address"] as! String)
        lblTotalEarned.text! = "Total earned: "+String(doctordata["amount_earned"] as! Int)
        lblTotalPatient.text! = "Total Patient: "+String(doctordata["total_patients"] as! Int)
        
    }
    
    
    //--------------------------------
    // MARK: Button Actions
    //--------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnCertificateTUI(_ sender: UIButton)
    {
//        let dic = certificatedata[indexPath.row] as! NSDictionary
        let obj = storyboard?.instantiateViewController(withIdentifier: "CertificateVC") as! CertificateVC
        obj.doctoridentification = iddoc
        navigationController?.pushViewController(obj, animated: true)
    }
    
    @IBAction func btnReviewTUI(_ sender: UIButton)
    {
        
        let obj = storyboard?.instantiateViewController(withIdentifier: "ReviewsVC") as! ReviewsVC
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    //--------------------------------
    // MARK: Web Services
    //--------------------------------
    
    
    
    
    
//    http://35.187.227.141/api/patient/service_packages
    
    
    
//    "{
//    ""doc_id"": 2,
//    ""patient_id"" : 3,
//    ""service_id"": 13
//}"
    
    
//    "{
//    ""msg"": ""List of Package's of doctors in service"",
//    ""status"": 1,
//    ""doctor"": {
//    ""name"": ""Shreeraj Jadeja"",
//    ""doc_id"": 2,
//    ""address"": ""Ahmedabad"",
//    ""amount_earned"": 0,
//    ""total_patients"": 0,
//    ""ratings"": 0
//    },
//    ""packages"": [
//    {
//    ""package_name"": ""Diabetes Package"",
//    ""package_amount"": ""$600"",
//    ""package_description"": ""I recommend Diabetic patients to buy this package<br><br>"",
//    ""package_id"": 4,
//    ""buy_status"": 2
//    }
//    ]
//}"
    
    
    
    
    func doctorpackage()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : iddoc,"patient_id": UserDefaults.standard.integer(forKey: "userId"),"service_id" : serviceid] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "patient/service_packages" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("List of Package's of doctors in service")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            self.packageData = (result["packages"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.doctordata = (result["doctor"] as! NSDictionary)
                            self.fillData()
                            self.tblPackages.reloadData()
                            SVProgressHUD.dismiss()
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
}
