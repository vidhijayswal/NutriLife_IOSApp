//
//  GoalsAndPaymentVC.swift
//  NutriLife
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD


var currentVC = String()

class GoalsAndPaymentVC: UIViewController,UITableViewDelegate, UITableViewDataSource
{
    
    
    
    //-----------------------------------
    // MARK: Outlets
    //-----------------------------------
    
    @IBOutlet weak var tblGoalsAndPayment: UITableView!
    
    @IBOutlet weak var btnAdd: UIButton!
    
    //-----------------------------------
    // MARK: Identifiers
    //-----------------------------------
    
    var timer = Timer()
    
    var doctorgoalData = NSMutableArray()
    
    var doctorPaymentData = NSMutableArray()
    
    
    //-----------------------------------
    // MARK: View Life Cycle
    //-----------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()

        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            btnAdd.isHidden = false
            goaldetails()
        }
        else
        {
            btnAdd.isHidden = true
        }
    }
    
    //-----------------------------------
    // MARK: Delegate Methods
    //-----------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if currentVC == "Goals"
        {
            return doctorgoalData.count
        }
        else
        {
            return doctorPaymentData.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
//            obj.imgDoctor.sd_setImage(with: URL(string: (dic["image"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
//            obj.lblDoctorName.text = (dic["patient_name"] as! String)
//            obj.lblServiceName.text = (dic["service_name"] as! String)
//            obj.lblStatus.text = (dic["status"] as! String)
//
//        }
//
        
        
        
let obj = tblGoalsAndPayment.dequeueReusableCell(withIdentifier: "tblCellGoalsAndPayment") as! tblCellGoalsAndPayment
        if currentVC == "Goals"
        {
            let dic = doctorgoalData[indexPath.row] as! NSDictionary
            obj.lblTitle.text = (dic["title"] as! String)
            obj.lblDescription.text = (dic["instruction"] as! String)
            obj.lblDateTime.text = (dic["created_at"] as! String)
        }
        else
        {
            //obj.lblTitle.text = PaymentData[indexPath.row]
            obj.lblDescription.text = "Payment description"
        }
        return obj
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if currentVC == "Goals"
        {
            let dic = doctorgoalData[indexPath.row] as! NSDictionary
            let obj = storyboard?.instantiateViewController(withIdentifier: "GoalDetailsVC") as! GoalDetailsVC
            obj.goalData = dic
            navigationController?.pushViewController(obj, animated: true)
        }
        else
        {
            let dic = doctorPaymentData[indexPath.row] as! NSDictionary
            let obj = storyboard?.instantiateViewController(withIdentifier: "PaymentDetailsVC") as! PaymentDetailsVC
            navigationController?.pushViewController(obj, animated: true)
        }
    }
    
    
    //-----------------------------------
    // MARK: User Defined Function
    //-----------------------------------
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            goaldetails()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    //-----------------------------------
    // MARK: Button Actions
    //-----------------------------------
    
    @IBAction func btnAddTUI(_ sender: UIButton)
    {
        if currentVC == "Goals"
        {
            let obj = storyboard?.instantiateViewController(withIdentifier: "AddGoalsVC") as! AddGoalsVC
            navigationController?.pushViewController(obj, animated: true)
        }
        else
        {
            let obj = storyboard?.instantiateViewController(withIdentifier: "AddPaymentRequestVC") as! AddPaymentRequestVC
            navigationController?.pushViewController(obj, animated: true)
        }
    }
    
    //-----------------------------------
    // MARK: Web Services
    //-----------------------------------

    
    
//    http://35.187.227.141/api/doctor/viewgoals
    
    
//    "{
//    ""service_id"":2,
//    ""doc_id"":3,
//    ""patient_id"":4
//}"
    
    
    
//    "{
//    ""msg"": ""Doctor's instructions for the patient."",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""title"": ""Breakfast details"",
//    ""instruction"": ""Take your breakfast before 10 AM"",
//    ""created_at"": ""13-Nov-2018 06:38""
//    }
//    ]
//}"
    
    func goaldetails()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["package_id": packageid ,"service_id": serviceid,"patient_id": id,"doc_id" : UserDefaults.standard.integer(forKey: "userId")] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/viewgoals" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Doctor's instructions for the patient.")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            
                            self.doctorgoalData = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblGoalsAndPayment.reloadData()
                            SVProgressHUD.dismiss()
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
            
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    
    
// http://localhost/nutrilife/api/specificpaymentrequest
    
    
//    "{
//    ""user_id"": 4,
//    ""doc_id"":3
//}
//
//OR
//
//    {
//    ""user_id"": 3,
//    ""patient_id"":4
//}"
    
    
    
    
//    "{
//    ""msg"": ""Payment Requests of specific doctor and patient"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""pr_id"": 2,
//    ""title"": ""Cough treatment"",
//    ""description"": ""Urgent payment required"",
//    ""amount"": 75,
//    ""doc_id"": 3,
//    ""doctor_name"": ""Shreeraj Jadeja"",
//    ""request_status"": ""Requested Payment"",
//    ""created_at"": ""04-Dec-2018 11:45""
//    }
//    ],
//    ""total_spent"": 75
//}"
    
    
    
    
    
    func paymentdetails()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId"),"user_id" : UserDefaults.standard.integer(forKey: "userId")] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "specificpaymentrequest" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Payment Requests of specific doctor and patient")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            
                            self.doctorPaymentData = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblGoalsAndPayment.reloadData()
                            SVProgressHUD.dismiss()
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
            
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    
    
}
