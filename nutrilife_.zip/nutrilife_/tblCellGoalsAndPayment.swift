//
//  tblCellGoalsAndPayment.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 01/11/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class tblCellGoalsAndPayment: UITableViewCell
{
    
    //---------------------------------------
    // MARK: Outlets
    //---------------------------------------

    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var lblDescription: UILabel!
    
    @IBOutlet weak var lblDateTime: UILabel!
    
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
