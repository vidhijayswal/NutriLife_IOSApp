//
//  tblCellRole.swift
//  Nutrilife
//
//  Created by Ashutosh Jani on 18/12/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class tblCellRole: UITableViewCell
{

    //-----------------------------
    // MARK: Outlets
    //-----------------------------
    
    @IBOutlet var lblRole: [UILabel]!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
