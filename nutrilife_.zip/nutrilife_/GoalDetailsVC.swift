//
//  GoalDetailsVC.swift
//  NutriLife
//
// 
//

import UIKit
import Alamofire
import SVProgressHUD

class GoalDetailsVC: UIViewController
{
    
    //---------------------------------
    // MARK: Outlets
    //---------------------------------
    
    @IBOutlet weak var lblGoalTitle: UILabel!
    
    @IBOutlet weak var lblDateTime: UILabel!

    @IBOutlet weak var txtDescription: UITextView!
    
    //---------------------------------
    // MARK: Identifiers
    //---------------------------------
    
    var goalData = NSDictionary()
    
    
    //---------------------------------
    // MARK: View Life Cycle
    //---------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()

        lblGoalTitle.text! = (goalData["title"] as! String)
        lblDateTime.text! = (goalData["created_at"] as! String)
        txtDescription.text! = (goalData["instruction"] as! String)
        
        txtDescription.isEditable = false
    }
    

    //---------------------------------
    // MARK: Delegate Methods
    //---------------------------------
    
    
    
    
    //---------------------------------
    // MARK: User Defined Functions
    //---------------------------------
    
    
    
    //---------------------------------
    // MARK: Button Actions
    //---------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    

    

}
