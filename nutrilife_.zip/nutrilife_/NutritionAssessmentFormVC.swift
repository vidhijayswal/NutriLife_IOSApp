//
//  NutritionAssessmentFormVC.swift
//  nutrilife_
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD

class NutritionAssessmentFormVC: UIViewController
{
    
    var timer = Timer()
    
    
    @IBOutlet weak var txtHealthStatus: UITextField!
    
    @IBOutlet weak var txtbreakfastMorning: UITextField!
    
    @IBOutlet weak var txtLunch: UITextField!
    @IBOutlet weak var txtBreakfastEvening: UITextField!
    
    @IBOutlet weak var txtDinner: UITextField!
    
    @IBOutlet weak var txtOtherHabits: UITextField!
    
    @IBOutlet weak var txtmedication: UITextField!
    
    @IBOutlet weak var txtDailySchedule: UITextView!
    
    @IBOutlet weak var txtOccupation: UITextField!
    
    @IBOutlet weak var txtIncome: UITextField!
    
    @IBOutlet weak var txtFoodExpenditure: UITextField!
    
    @IBOutlet weak var txtSpecialRequest: UITextView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        viewNutritionAssessment()
        
        
    }
    
    
    
    
    
    
    
    
//    http://35.187.227.141/api/doctor/viewmntforms
    
    
    
//    "{
//    ""doc_id"":3,
//    ""patient_id"":4
//}"
    
    
    
//    "{
//    ""msg"": ""Patient's MNT forms"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""mnt_id"": 2,
//    ""health_status"": ""Very weak"",
//    ""breakfast"": ""Cereals"",
//    ""lunch"": ""Punjabi"",
//    ""hi_tea"": ""Tea"",
//    ""dinner"": ""Chinese"",
//    ""other_habits"": ""No bad habits"",
//    ""on_going_medication"": ""None"",
//    ""daily_schedule"": ""None"",
//    ""occupation"": ""Web Developer"",
//    ""income"": 5000,
//    ""food_expenditure"": ""$500"",
//    ""special_request"": ""None""
//    }
//    ]
//}"
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
                viewNutritionAssessment()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Is Not Available")
        }
    }
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    
    func viewNutritionAssessment()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId"),"patient_id" : id] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/viewmntforms" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Patient's MNT forms")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                            let data = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            
                            let dic = data[0] as! NSDictionary
                            self.txtHealthStatus.text = (dic["health_status"] as! String)
                            self.txtbreakfastMorning.text = (dic["breakfast"] as! String)
                            
                            self.txtLunch.text = (dic["lunch"] as! String)
                            self.txtBreakfastEvening.text = (dic["supper"] as! String)
                            
                            self.txtDinner.text = (dic["dinner"] as! String)
                            self.txtOtherHabits.text = (dic["other_habits"] as! String)
                            
                            self.txtmedication.text = (dic["on_going_medication"] as! String)
                            
                            self.txtDailySchedule.text = (dic["daily_schedule"] as! String)
                            self.txtOccupation.text = (dic["occupation"] as! String)
                            
                            self.txtIncome.text = (dic["income"] as! String)
                            self.txtFoodExpenditure.text = (dic["food_expenditure"] as! String)
                            
                            self.txtSpecialRequest.text = (dic["special_request"] as! String)
                
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    

}
