//
//  PackageDetailsVC.swift
//  NutriLife
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD


class PackageDetailsVC: UIViewController
{
    //----------------------------------
    // MARK: Outlets
    //----------------------------------
    
    @IBOutlet weak var lblPackageName: UILabel!
    
    @IBOutlet weak var lblPackagePrice: UILabel!
    
    @IBOutlet weak var lblServiceName: UILabel!
    
    @IBOutlet weak var txtPackageDescription: UITextView!
    
    @IBOutlet weak var btnBuyservice: UIButton!
    
    
    
    //----------------------------------
    // MARK: Identifiers
    //----------------------------------
    
    var timer = Timer()
    var idservice = Int()
    var packagedata =  NSDictionary()
    var doctor_identification = Int()
    var serviceid_patientside = Int()
    //----------------------------------
    // MARK: View Life Cycle
    //----------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            btnBuyservice.isHidden = true
            viewpackage()
        }
        else
        {
            btnBuyservice.isHidden = false
            patientviewpackage()
        }

        
    }
    
    //----------------------------------
    // MARK: Delegate Methods
    //----------------------------------
    
    
    
    //----------------------------------
    // MARK: User Defined Functions
    //----------------------------------
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            viewpackage()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Is Not Available")
        }
    }
    
    
    //----------------------------------
    // MARK: Button Actions
    //----------------------------------
    
   
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    
    
    @IBAction func btnBuyserviceTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "MNTForm1VC") as! MNTForm1VC
        
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    //----------------------------------
    // MARK: Web Services
    //----------------------------------
    
    
    
//    http://35.187.227.141/api/doctor/packages
    
    
//    "{
//    ""doc_id"": 2,
//    ""service_id"": 1
//}"
    
    
//    "{
//    ""msg"": ""3 packages available"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""doc_id"": 2,
//    ""doc_name"": ""Shreeraj Jadeja"",
//    ""location"": ""Ahmedabad"",
//    ""service_id"": 1,
//    ""service_name"": ""Infants & Pediatric"",
//    ""package_id"": 1,
//    ""package_name"": ""Viral Disease"",
//    ""package_amount"": 200,
//    ""package_description"": ""This is Basic&nbsp;<br><b>Package including viral disease</b>""
//    },
//    {
//    ""doc_id"": 2,
//    ""doc_name"": ""Shreeraj Jadeja"",
//    ""location"": ""Ahmedabad"",
//    ""service_id"": 1,
//    ""service_name"": ""Infants & Pediatric"",
//    ""package_id"": 2,
//    ""package_name"": ""Skin Infections"",
//    ""package_amount"": 80,
//    ""package_description"": ""This is Basic package of add skin infections""
//    },
//    {
//    ""doc_id"": 2,
//    ""doc_name"": ""Shreeraj Jadeja"",
//    ""location"": ""Ahmedabad"",
//    ""service_id"": 1,
//    ""service_name"": ""Infants & Pediatric"",
//    ""package_id"": 3,
//    ""package_name"": ""Migrant"",
//    ""package_amount"": 300,
//    ""package_description"": ""Its contineus<br>&nbsp;headache usually for 17hours""
//    }
//    ]
//}"
    
    
    
    

    
    func viewpackage()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId"),"service_id" : idservice] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/packages" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("3 packages available")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            let data = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.packagedata = data[0] as! NSDictionary
                            
                            self.lblPackageName.text = (self.packagedata["package_name"] as! String)
                            self.lblPackagePrice.text = String(self.packagedata["package_amount"] as! Int)
                            self.lblServiceName.text = (self.packagedata["service_name"] as! String)
                            self.txtPackageDescription.text = (self.packagedata["package_description"] as! String).html2String
                           
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }

    
    
    
    
    
    
    
    
    
    
    
    func patientviewpackage()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : doctor_identification,"service_id" : serviceid_patientside] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/packages" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("3 packages available")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            let data = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.packagedata = data[0] as! NSDictionary
                            
                            self.lblPackageName.text = (self.packagedata["package_name"] as! String)
                            self.lblPackagePrice.text = String(self.packagedata["package_amount"] as! Int)
                            self.lblServiceName.text = (self.packagedata["service_name"] as! String)
                            self.txtPackageDescription.text = (self.packagedata["package_description"] as! String).html2String
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
}
