//
//  tblCellVIdeo.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 31/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class tblCellVIdeo: UITableViewCell
{
    //-----------------------------
    // MARK: Outlets
    //-----------------------------
    
    @IBOutlet weak var imgVideo: UIImageView!
    
    @IBOutlet weak var lblVideoName: UILabel!
    
    @IBOutlet weak var lblVideoDescription: UILabel!
    
    @IBOutlet weak var videoSwitch: UISwitch!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
