//
//  tblCellServicesPatientSIde.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 30/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class tblCellServicesPatientSIde: UITableViewCell
{
    
    @IBOutlet weak var lblServiceName: UILabel!
    
    @IBOutlet weak var lblDoctorNumber: UILabel!
    
    @IBOutlet weak var lblPackageNumber: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
