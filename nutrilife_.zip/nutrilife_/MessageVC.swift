//
//  MessageVC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 30/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class MessageVC: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    
    
    
    //-----------------------------------
    // MARK: Outlets
    //-----------------------------------

    @IBOutlet weak var tblMessage: UITableView!
    
    
    //-----------------------------------
    // MARK: Identifiers
    //-----------------------------------
    
    var MessageArr = ["Person 1", "Person 1", "Person 1", "Person 1"]
    
    
    //-----------------------------------
    // MARK: View Life Cycle
    //-----------------------------------
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //-----------------------------------
    // MARK: Delegate Methods
    //-----------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return MessageArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let obj = tblMessage.dequeueReusableCell(withIdentifier: "tblCellMessages") as! tblCellMessages
        obj.lblUserName.text = MessageArr[indexPath.row]
        return obj
    }
    
    //-----------------------------------
    // MARK: User Defined Functions
    //-----------------------------------
    
    
    //-----------------------------------
    // MARK: Button Actions
    //-----------------------------------
    
    
    //-----------------------------------
    // MARK: Web Services
    //-----------------------------------

}
