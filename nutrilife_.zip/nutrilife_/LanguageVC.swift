//
//  LanguageVC.swift
//  Nutrilife
//
// 
//

import UIKit

class LanguageVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    //-----------------------------------
    // MARK: Outlets
    //-----------------------------------
    
    @IBOutlet weak var languageView: UIView!
    
    @IBOutlet weak var btnLanguage: UIButton!
    
    @IBOutlet weak var btnHideLanguageOption: UIButton!
    
    @IBOutlet weak var tblLanguage: UITableView!
    
    
    
    //-----------------------------------
    // MARK: Identifiers
    //-----------------------------------
    
    
    var languageList = ["English", "Chinese","Vietnammes"]
    
    
    //-----------------------------------
    // MARK: View Life Cycle
    //-----------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()

        btnHideLanguageOption.isHidden = true
        tblLanguage.isHidden = true
        languageView.layer.borderWidth = 1
        languageView.layer.borderColor = UIColor.lightGray.cgColor
    
    }
    
    //-----------------------------------
    // MARK: Delegate Methods
    //-----------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return languageList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tblLanguage.dequeueReusableCell(withIdentifier: "tblCellLanguages") as! tblCellLanguages
        
        cell.lblLanguage.text = languageList[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        btnHideLanguageOption.isHidden = true
        tblLanguage.isHidden = true
        btnLanguage.setTitle(languageList[indexPath.row], for: .normal)
        
    }
    
    //-----------------------------------
    // MARK: User Defined Functions
    //-----------------------------------
    
    
    
    //-----------------------------------
    // MARK: Button Actions
    //-----------------------------------
    
    @IBAction func btnLanguageTUI(_ sender: UIButton)
    {
        tblLanguage.isHidden = false
        btnHideLanguageOption.isHidden = false
    }
    
    @IBAction func btnHideLanguageOptionTUI(_ sender: UIButton)
    {
        btnHideLanguageOption.isHidden = true
        tblLanguage.isHidden = true
    }

    @IBAction func btnNextTUI(_ sender: UIButton)
    {
        
        if UserDefaults.standard.integer(forKey: "isLogin") == 1
        {
            let obj = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
            self.navigationController?.pushViewController(obj, animated: false)
            
        }
        else
        {
            let obj = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            
            self.navigationController?.pushViewController(obj, animated: true)
        }
        
    }
    
   
}
