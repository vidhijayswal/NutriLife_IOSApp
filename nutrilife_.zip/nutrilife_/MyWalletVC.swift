//
//  MyWalletVC.swift
//  NutriLife
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD

class MyWalletVC: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    
    
    //----------------------------
    // MARK: Outlets
    //----------------------------

    @IBOutlet weak var tblWallet: UITableView!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var lblFooterTitle: UILabel!
    
    @IBOutlet weak var lblFooterValue: UILabel!
    
    @IBOutlet weak var footerView: UIView!
    
    @IBOutlet weak var lbltitle: UILabel!
    
    //----------------------------
    // MARK: Identifiers
    //----------------------------
    
    var timer = Timer()
    
    var walletdata = NSMutableArray()
    
    //----------------------------
    // MARK: View Life Cycle
    //----------------------------
    override func viewDidLoad() {
        super.viewDidLoad()

        footerView.layer.borderColor = UIColor.darkGray.cgColor
        footerView.layer.borderWidth = 1
        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            lblFooterTitle.text = "Total Earnings:"
            doctorwallet()
        }
        else
        {
            lbltitle.text = "My Payments"
            lblFooterTitle.text = "Total Spent:"
        }
        
        // Do any additional setup after loading the view.
    }
    

    //----------------------------
    // MARK: Delegate Methods
    //----------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return walletdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
         let obj = tblWallet.dequeueReusableCell(withIdentifier: "tblCellWallet") as! tblCellWallet
        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            let dic = walletdata[indexPath.row] as! NSDictionary
            
           obj.lblTransactionTitle.text = (dic["title"] as! String)
           obj.lblTransactionDetail.text = (dic["description"] as! String)
            obj.lblDateTime.text = (dic["created_at"] as! String)
        }
        return obj
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "PaymentDetailsVC") as! PaymentDetailsVC
        navigationController?.pushViewController(obj, animated: true)
    }
    
    //----------------------------
    // MARK: User Defined Functions
    //----------------------------
    
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            doctorwallet()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    //----------------------------
    // MARK: Button Actions
    //----------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    //----------------------------
    // MARK: Web Services
    //----------------------------
//    http://35.187.227.141/api/mywallet
    
    
    
//    "{
//    ""id"":3 (Doctor ID)
//}
//
//OR
//
//    {
//    ""id"":4 (Patient ID)
//}"
    
    
//    "{
//    ""msg"": ""Doctor Wallet details"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""title"": ""Cough treatment"",
//    ""description"": ""Urgent payment required"",
//    ""amount"": 100,
//    ""patient_id"": 4,
//    ""patient_name"": ""Sulay Panchal"",
//    ""request_status"": ""Pending"",
//    ""total_earned"": 200,
//    ""created_at"": ""13-Nov-2018 13:36""
//    }
//    ]
//}
//
//OR
//
//    {
//    ""msg"": ""Patient Wallet details"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""title"": ""Cough treatment"",
//    ""description"": ""Urgent payment required"",
//    ""amount"": 100,
//    ""doc_id"": 3,
//    ""doctor_name"": ""Shreeraj Jadeja"",
//    ""request_status"": ""Requested Payment"",
//    ""total_spent"": 200,
//    ""created_at"": ""13-Nov-2018 13:36""
//    }
//    ]
//}"
    
    
    
    
    func doctorwallet()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["id" : UserDefaults.standard.integer(forKey: "userId")] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "mywallet" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Doctor Wallet details")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            
                            self.walletdata = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblWallet.reloadData()
                            SVProgressHUD.dismiss()
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
                }
            
            }
            
            else
            {
                self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
                PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
            }
        }

}

