//
//  MyDoctorVC.swift
//  NutriLife
//
//  

import UIKit
import Alamofire
import SVProgressHUD
import SDWebImage

class MyDoctorVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    
    
    //-----------------------------
    // MARK: Outlets
    //-----------------------------
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var tblMyDoctor: UITableView!
    
    @IBOutlet weak var lblTitle: UILabel!
    
    //-----------------------------
    // MARK: Identifiers
    //-----------------------------
    
    var timer = Timer()
    
    var doctorPatientData = NSMutableArray()
    
    var mydoctordata = NSMutableArray()
    //-----------------------------
    // MARK: View Life Cycle
    //-----------------------------

    override func viewDidLoad() {
        super.viewDidLoad()

        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            lblTitle.text = "My Patient"
            mypatients()
        }
        else
        {
            lblTitle.text = "My Doctor"
            mydoctors()
        }
    }
    

    //-----------------------------
    // MARK: Delegate Methods
    //-----------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            return doctorPatientData.count
        }
        else
        {
            return mydoctordata.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let obj = tblMyDoctor.dequeueReusableCell(withIdentifier: "tblCellMyDoctor") as! tblCellMyDoctor
        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            let dic = doctorPatientData[indexPath.row] as! NSDictionary
            obj.imgDoctor.sd_setImage(with: URL(string: (dic["image"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
            obj.lblDoctorName.text = (dic["patient_name"] as! String)
            obj.lblServiceName.text = (dic["service_name"] as! String)
            obj.lblStatus.text = (dic["status"] as! String)
            
        }
        else
        {
            let dic = mydoctordata[indexPath.row] as! NSDictionary
            obj.imgDoctor.sd_setImage(with: URL(string: (dic["image"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
            obj.lblDoctorName.text = (dic["doc_name"] as! String)
            obj.lblServiceName.text = (dic["service_name"] as! String)
            obj.lblStatus.text = (dic["status"] as! String)
            
        }
        
        return obj
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            let dic = doctorPatientData[indexPath.row] as! NSDictionary
            
            let obj = storyboard?.instantiateViewController(withIdentifier: "MyDoctorDetails") as! MyDoctorDetails
            
            obj.docData = dic
            id = dic["patient_id"] as! Int
            serviceid = dic["service_id"] as! Int
            packageid = dic["package_id"] as! Int
            navigationController?.pushViewController(obj, animated: true)
        }
        else
        {
            let dic = mydoctordata[indexPath.row] as! NSDictionary
            
            let obj = storyboard?.instantiateViewController(withIdentifier: "MyDoctorDetails") as! MyDoctorDetails
            
            obj.docData = dic
            id = dic["doc_id"] as! Int
            serviceid = dic["service_id"] as! Int
            packageid = dic["package_id"] as! Int
            navigationController?.pushViewController(obj, animated: true)
        }
        
       
    }
    
    //-----------------------------
    // MARK: User Defined Function
    //-----------------------------
    
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            mypatients()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    
    
    
    //-----------------------------
    // MARK: Button Actions
    //-----------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    //-----------------------------
    // MARK: Web Services
    //-----------------------------
    
    
    
//    http://35.187.227.141/api/doctor/mypatients
    
    
//    "{
//    ""doc_id"":3
//}"
    
    
//    "{
//    ""msg"": ""Your Patient's List"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""patient_id"": 4,
//    ""patient_name"": ""Sulay Panchal"",
//    ""image"": ""http://localhost/nutrilife/storage/uploads/sgm_1540893496.png"",
//    ""service_id"": 2,
//    ""service_name"": ""Service 2"",
//    ""package_id"": 2,
//    ""patient_bmi"": 9.7,
//    ""status"": ""On Going"",
//    ""last_message"": ""User 1 in room room-12-13"",
//    ""sent_date"": ""2017-10-07"",
//    ""sent_time"": ""12:28 PM""
//    }
//    ]
//}"

    
    
    func mypatients()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId")] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/mypatients" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Your Patient's List")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            
                            self.doctorPatientData = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblMyDoctor.reloadData()
                            SVProgressHUD.dismiss()
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
            
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    
    
    
    
    
    
    
    
    
//http://35.187.227.141/api/patient/mydoctors
    
    
    
//    "{
//    ""patient_id"":4
//}"
    
    
    
    
//    "{
//    ""msg"": ""Your Doctor's List"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""doc_id"": 3,
//    ""doc_name"": ""Shreeraj Jadeja"",
//    ""image"": ""http://http://35.187.227.141/storage/uploads/sgm2_1540893810.png"",
//    ""service_id"": 1,
//    ""service_name"": ""Service 1"",
//    ""status"": ""On Going""
//    }
//    ]
//}"
    
    
    
    
    func mydoctors()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["patient_id" : UserDefaults.standard.integer(forKey: "userId")] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "patient/mydoctors" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Your Doctor's List")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            
                            self.mydoctordata = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblMyDoctor.reloadData()
                            SVProgressHUD.dismiss()
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
            
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
}
