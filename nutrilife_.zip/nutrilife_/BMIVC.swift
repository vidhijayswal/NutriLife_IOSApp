//
//  BMIVC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 30/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD

class BMIVC: UIViewController, UITextFieldDelegate
{
    
    //----------------------------
    // MARK: Outlets
    //----------------------------
    
    @IBOutlet weak var btnMale: UIButton!
    
    @IBOutlet weak var btnFemale: UIButton!
    
    @IBOutlet weak var txtAge: UITextField!
    
    @IBOutlet weak var txtWeight: UITextField!
    
    @IBOutlet weak var btnBack: UIButton!
    
    @IBOutlet weak var txtHeight: UITextField!
    
    @IBOutlet weak var InYearsView: UIView!
    
    @IBOutlet weak var AgeView: UIView!
    
    @IBOutlet weak var InLbsView: UIView!
    
    @IBOutlet weak var WeightView: UIView!
    
    @IBOutlet weak var InCmView: UIView!
    
    @IBOutlet weak var HeightView: UIView!
    
    @IBOutlet weak var WeightOptionView: UIView!
    
    @IBOutlet weak var lblWeight: UILabel!
    
    @IBOutlet weak var btnHideWeightOption: UIButton!
    
    //----------------------------
    // MARK: Identifiers
    //----------------------------
    
    var timer = Timer()
    var height = Double()
    var weight = Double()
    var result = String()
    var patientbmi = Double()
    
    //----------------------------
    // MARK: View Life Cycle
    //----------------------------
    
    

    override func viewDidLoad()
    {
        super.viewDidLoad()

        txtAge.delegate = self
        txtWeight.delegate = self
        txtHeight.delegate = self
        
        AgeView.layer.borderColor = UIColor.lightGray.cgColor
        AgeView.layer.borderWidth = 1
        
        InYearsView.layer.borderColor = UIColor.lightGray.cgColor
        InYearsView.layer.borderWidth = 1
        
        WeightView.layer.borderColor = UIColor.lightGray.cgColor
        WeightView.layer.borderWidth = 1
        
        InLbsView.layer.borderColor = UIColor.lightGray.cgColor
        InLbsView.layer.borderWidth = 1
        
        HeightView.layer.borderColor = UIColor.lightGray.cgColor
        HeightView.layer.borderWidth = 1
        
        InCmView.layer.borderColor = UIColor.lightGray.cgColor
        InCmView.layer.borderWidth = 1
        
        WeightOptionView.isHidden = true
        btnHideWeightOption.isHidden = true
        
        
        
        
        
        
    }
    
    //----------------------------
    // MARK: Delegate Methods
    //----------------------------
    
    
    
    
    
    //----------------------------
    // MARK: User Defined Function
    //----------------------------
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            updateorstorebmi()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet is Not Available")
        }
    }
    
    
    func bmi()
    {
        weight = Double(txtWeight.text!)!
        height = Double(txtHeight.text!)! / 100
        patientbmi = weight / (height * height)
        result = (String(format: "%.2f", patientbmi))
        
        PopUp(Controller: self, title: "Message", message: "Your BMI is: \(result)")
        //print("Your BMI is: \(result)")
    }
    
    
    
    //----------------------------
    // MARK: Button Actions
    //----------------------------
    
    @IBAction func btnMaleTUI(_ sender: UIButton)
    {
        if !btnMale.isSelected
        {
            btnMale.isSelected = true
            btnFemale.isSelected = false
        }
    }
    
    @IBAction func btnFemaleTUI(_ sender: UIButton)
    {
        if !btnFemale.isSelected
        {
            btnFemale.isSelected = true
            btnMale.isSelected = false
        }
    }
    
    @IBAction func btnInLbsTUI(_ sender: UIButton)
    {
        WeightOptionView.isHidden = true
        btnHideWeightOption.isHidden = true
        lblWeight.text = "In lbs"
    }
    
    @IBAction func btnInKgsTUI(_ sender: UIButton)
    {
        WeightOptionView.isHidden = true
            btnHideWeightOption.isHidden = true
        lblWeight.text = "In Kgs"
    }
    
    @IBAction func btnWeightOptionTUI(_ sender: UIButton)
    {
        WeightOptionView.isHidden = false
        btnHideWeightOption.isHidden = false
    }
    @IBAction func btnHideWeightOptionTUI(_ sender: UIButton)
    {
        btnHideWeightOption.isHidden = true
        WeightOptionView.isHidden = true
    }
    
    
    @IBAction func btnBack(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnCalculate(_ sender: UIButton)
    {
        
        bmi()
       // updateorstorebmi()
    }
    
    
    
    //----------------------------
    // MARK: Web Services
    //----------------------------
    
    
    
    
    
//    http://35.187.227.141/api/patient/bmi
    
    
    
//    "{
//    ""patient_id"":4,
//    ""bmi"":9.7
//}"
    
    
    
    
//    "{
//    ""msg"": ""Success! BMI updated."",
//    ""status"": 1
//}"
    
    
    
    func updateorstorebmi()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["patient_id" : UserDefaults.standard.integer(forKey: "userId")] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "patient/bmi" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Success! BMI updated.")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                            PopUp(Controller: self, title: "Message", message: (result["msg"] as! String))
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    

}
