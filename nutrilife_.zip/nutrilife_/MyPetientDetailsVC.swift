//
//  MyPetientDetailsVC.swift
//  NutriLife
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD

class MyPetientDetailsVC: UIViewController
{
    
    //----------------------------------
    // MARK: Outlets
    //----------------------------------

    @IBOutlet weak var lblLocation: UILabel!
    
    @IBOutlet weak var lblEmail: UILabel!
    
    @IBOutlet weak var lblDOB: UILabel!
    
    @IBOutlet weak var lblBMI: UILabel!
    
    @IBOutlet weak var lblTotalSpent: UILabel!
    
    @IBOutlet weak var lblServicesUsed: UILabel!
    
    
    @IBOutlet weak var lblReviewsGiven: UILabel!
    //----------------------------------
    // MARK: Identifiers
    //----------------------------------
    
    var timer = Timer()
    
    //----------------------------------
    // MARK: View Life Cycle
    //----------------------------------
    override func viewDidLoad()
    {
        super.viewDidLoad()
        patientdetail()

        
    }
    
    //----------------------------------
    // MARK: User Defined Function
    //----------------------------------
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            patientdetail()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Is Not Available")
        }
    }
    
    
    //----------------------------------
    // MARK: Button Actions
    //----------------------------------
    
    @IBAction func btnMNTFormsTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "NutritionAssessmentFormVC") as! NutritionAssessmentFormVC
        
        navigationController?.pushViewController(obj, animated: true)
        
    }
    
    //----------------------------------
    // MARK: Web Services
    //----------------------------------
    
//    http://35.187.227.141/api/patient/profile
    
    
    
    
//    "{
//    ""patient_id"":4
//}"
    
    
    
    
//    "{
//    ""msg"": ""Patient's Profile"",
//    ""status"": 1,
//    ""data"": {
//    ""fname"": ""Sulay"",
//    ""lname"": ""Panchal"",
//    ""email"": ""sulay.qrioustech@gmail.com"",
//    ""image"": ""http://localhost/nutrilife/storage/uploads/sgm_1540893496.png"",
//    ""dob"": ""1993-02-01"",
//    ""address"": ""Ahmedabad"",
//    ""reviews_given"": 3,
//    ""bmi"": 9.7,
//    ""total_spent"": ""$75"",
//    ""services_used"": 1
//    }
//}"
    
    
    func patientdetail()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["patient_id": id] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "patient/profile" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Your query successfully sent!")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        
                        if (result["status"] as! Int) == 0
                        {
                            SVProgressHUD.dismiss()
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                            let data = result["data"] as! NSDictionary
                            self.lblLocation.text = "Location: "+(data["address"] as! String)
                            self.lblEmail.text = "Email: "+(data["email"] as! String)
                            
                            self.lblDOB.text = "DOB: "+((data["dob"] as! String))
                            self.lblBMI.text = "BMI: "+(String(data["bmi"] as! Double))
                            
                            self.lblTotalSpent.text = "Total Spent: "+(data["total_spent"] as! String)
                            
                            self.lblServicesUsed.text = "Services used: "+String(data["services_used"] as! Int)
                            self.lblReviewsGiven.text = "Reviews given: "+String(data["reviews_given"] as! Int)
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    

}
