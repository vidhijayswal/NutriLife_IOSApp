//
//  PaymentDetailsVC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 01/11/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class PaymentDetailsVC: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    
    
    
    //-----------------------------------
    // MARK: Outlets
    //-----------------------------------
    
    @IBOutlet weak var tblPaymentRequest: UITableView!
    
    @IBOutlet weak var btnAccept: UIButton!
    
    @IBOutlet weak var btnDecline: UIButton!
    
    @IBOutlet weak var viewButton: UIView!
    //-----------------------------------
    // MARK: Identifiers
    //-----------------------------------
    
    
    //-----------------------------------
    // MARK: View Life Cycle
    //-----------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()

        if UserDefaults.standard.string(forKey: "userType") == "Doctor"
        {
            viewButton.isHidden = true
        }
        else
        {
            viewButton.isHidden = false
        }
        
        // Do any additional setup after loading the view.
    }
    
    //-----------------------------------
    // MARK: Delegate Methods
    //-----------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if indexPath.row == 0
        {
            let obj = tblPaymentRequest.dequeueReusableCell(withIdentifier: "tblCellPaymentRequest") as! tblCellPaymentRequest
            	
            return obj
            
        }
        else
        {
            let obj = tblPaymentRequest.dequeueReusableCell(withIdentifier: "tblCellPaymentAction") as! tblCellPaymentAction
            if indexPath.row == 1
            {
                obj.imgStatus.image = UIImage(named: "icon_accept")
            }
            else
            {
                obj.imgStatus.image = UIImage(named: "icon_decline")
            }
            return obj
        }
    }
    
    //-----------------------------------
    // MARK: User Defined Functions
    //-----------------------------------
    
    
    //-----------------------------------
    // MARK: Button Actions
    //-----------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    //-----------------------------------
    // MARK: Web Services
    //-----------------------------------

}
