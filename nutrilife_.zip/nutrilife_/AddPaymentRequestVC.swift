//
//  AddPaymentRequestVC.swift
//  NutriLife
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD

class AddPaymentRequestVC: UIViewController, UITextFieldDelegate, UITextViewDelegate, UITableViewDataSource, UITableViewDelegate
{
    
    //---------------------------------
    // MARK: Outlets
    //---------------------------------

    @IBOutlet weak var txtAmount: UITextField!
    
    @IBOutlet weak var lblAmountError: UILabel!
    
    @IBOutlet weak var currencyView: UIView!
    
    @IBOutlet weak var lblCurrency: UILabel!
    
    @IBOutlet weak var txtDescription: UITextView!
    
    @IBOutlet weak var lblDescriptionError: UILabel!
    
    @IBOutlet weak var tblCurrency: UITableView!
    
    @IBOutlet weak var btnHideCurrencyOption: UIButton!
    
    @IBOutlet weak var txtTitle: UITextField!
    
    @IBOutlet weak var lblTitleError: UILabel!
    
    //---------------------------------
    // MARK: Identifiers
    //---------------------------------

    
    var currencyArr = ["USD","INR"]
    var timer = Timer()
    
    
    //---------------------------------
    // MARK: View Life Cycle
    //---------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()

        lblTitleError.isHidden = true
        lblAmountError.isHidden = true
        lblDescriptionError.isHidden = true
        
        txtTitle.delegate = self
        txtDescription.delegate = self
        txtAmount.delegate = self
        
        txtDescription.layer.cornerRadius = 5
        txtDescription.layer.borderWidth = 1
        txtDescription.layer.borderColor = UIColor.lightGray.cgColor
        
        currencyView.layer.cornerRadius = 5
        currencyView.layer.borderWidth = 1
        currencyView.layer.borderColor = UIColor.lightGray.cgColor
        
        txtAmount.addTarget(self, action: #selector(txtAmountValueChanged), for: .editingChanged)
        
        txtTitle.addTarget(self, action: #selector(txtTitleValueChanged), for: .editingChanged)
        
        btnHideCurrencyOption.isHidden = true
        
        tblCurrency.isHidden = true
        // Do any additional setup after loading the view.
    }
    
    //---------------------------------
    // MARK: Delegate Methods
    //---------------------------------

    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        self.view.endEditing(true)
        return true
    }
    
    func textViewDidChange(_ textView: UITextView)
    {
        if txtDescription.text == ""
        {
            lblDescriptionError.isHidden = false
        }
        else
        {
            lblDescriptionError.isHidden = true
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return currencyArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let obj = tblCurrency.dequeueReusableCell(withIdentifier: "tblCellPaymentCurrency") as! tblCellPaymentCurrency
        obj.lblCurrency.text = currencyArr[indexPath.row]
        return obj
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        lblCurrency.text = currencyArr[indexPath.row]
        tblCurrency.isHidden = true
        btnHideCurrencyOption.isHidden = true
    }
    
    //---------------------------------
    // MARK: User Defined Functions
    //---------------------------------

    @objc func txtTitleValueChanged()
    {
        if txtTitle.text == ""
        {
            lblTitleError.isHidden = false
        }
        else
        {
            lblTitleError.isHidden = true
        }
    }
    
    @objc func txtAmountValueChanged()
    {
        if txtAmount.text == ""
        {
            lblAmountError.isHidden = false
        }
        else
        {
            lblAmountError.isHidden = true
        }
    }
    
    
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            addpaymentrequest()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    //---------------------------------
    // MARK: Button Actions
    //---------------------------------

    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnShowCurrencyOption(_ sender: Any)
    {
        btnHideCurrencyOption.isHidden = false
        tblCurrency.isHidden = false
    }
    @IBAction func btnHideCurrencyOptionTUI(_ sender: UIButton)
    {
        btnHideCurrencyOption.isHidden = true
        tblCurrency.isHidden = true
    }
    
    @IBAction func btnAddRequest(_ sender: UIButton)
    {
        if txtTitle.text! == ""
        {
            lblTitleError.isHidden = false
        }
        else if txtDescription.text! == ""
        {
            lblDescriptionError.isHidden = false
        }
        else if txtAmount.text! == ""
        {
            lblAmountError.isHidden = false
        }
        else
        {
            addpaymentrequest()
            navigationController?.popViewController(animated: true)
        }
        
        
    }
    
    //---------------------------------
    // MARK: Web Services
    //---------------------------------

    
    
    
//    http://35.187.227.141/api/doctor/sendpaymentrequest
    
    
    
//    "{
//    ""service_id"":2,
//    ""package_id"":2,
//    ""doc_id"":3,
//    ""patient_id"":4,
//    ""title"":""Cough treatment"",
//    ""description"":""Urgent payment required""
//}"
    
    
    
    
//    "{
//    ""msg"": ""Success! Request sent to the patient."",
//    ""status"": 1
//}"

    
    
    func addpaymentrequest()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["service_id" : serviceid,"package_id" :packageid,"doc_id": UserDefaults.standard.integer(forKey: "userId"),"patient_id": id ,"title": txtTitle.text!, "description": txtDescription.text!] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/sendpaymentrequest" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Success! Request sent to the patient.")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        
                        if (result["status"] as! Int) == 0
                        {
                            SVProgressHUD.dismiss()
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                            PopUp(Controller: self, title: "Message", message: (result["msg"] as! String))
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
}
