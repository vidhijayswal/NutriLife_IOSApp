//
//  ContactUsVC.swift
//  NutriLife
//
//
//

import UIKit
import Alamofire
import SVProgressHUD

class ContactUsVC: UIViewController, UITextFieldDelegate, UITextViewDelegate
{
    
    //-------------------------------
    // MARK: Outlets
    //-------------------------------
 
    @IBOutlet weak var txtSubject: UITextField!
    
    @IBOutlet weak var lblSubjectError: UILabel!
    
    @IBOutlet weak var txtMessage: UITextView!
    
    @IBOutlet weak var lblMessageError: UILabel!
    //-------------------------------
    // MARK: Identifiers
    //-------------------------------
    
    var timer = Timer()
    
    //-------------------------------
    // MARK: View Life Cycle
    //-------------------------------
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        lblSubjectError.isHidden = true
        lblMessageError.isHidden = true
        
        txtMessage.layer.borderColor = UIColor.lightGray.cgColor
        txtMessage.layer.borderWidth = 1
        
        txtSubject.delegate = self
        txtMessage.delegate = self
        
        txtSubject.addTarget(self, action: #selector(txtSubjectValueChanged), for: .editingChanged)
        
    }
    
    //-------------------------------
    // MARK: Delegate Methods
    //-------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    func textViewDidChange(_ textView: UITextView) {
        if txtMessage.text == ""
        {
            lblMessageError.isHidden = false
        }
        else
        {
            lblMessageError.isHidden = true
        }
    }
    
    
    //-------------------------------
    // MARK: User Defined Function
    //-------------------------------
    
    @objc func txtSubjectValueChanged()
    {
        if txtSubject.text == ""
        {
            lblSubjectError.isHidden = false
        }
        else
        {
            lblSubjectError.isHidden = true
        }
    }
    
    
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            contactus()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Is Not Available")
        }
    }
    
    //-------------------------------
    // MARK: Button Actions
    //-------------------------------
    
    
    
    
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }

    @IBAction func btnSubmit(_ sender: UIButton)
    {
        if txtSubject.text! == ""
        {
            lblSubjectError.isHidden = false
        }
        else if txtMessage.text! == ""
        {
            lblMessageError.isHidden = false
        }
        else
        {
            contactus()
            navigationController?.popViewController(animated: true)
        }
        
        
    }
    //-------------------------------
    // MARK: Web Services
    //-------------------------------
    
    
    
    //http://35.187.227.141/api/contact_us
    
//    "{
//    ""user_id"":3,
//    ""subject"":""Payment issues"",
//    ""message"":""Payment not received yet.""
//}"
    
    
    
//    "{
//    ""msg"": ""Your query successfully sent!"",
//    ""status"": 1
//}"



    func contactus()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["user_id": UserDefaults.standard.integer(forKey: "userId"), "subject": txtSubject.text!, "message": txtMessage.text!] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "contact_us" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Your query successfully sent!")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        
                        if (result["status"] as! Int) == 0
                        {
                            SVProgressHUD.dismiss()
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                            PopUp(Controller: self, title: "Message", message: (result["msg"] as! String))
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }

}
