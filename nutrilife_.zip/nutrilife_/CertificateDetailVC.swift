//
//  CertificateDetailVC.swift
//  nutrilife_
//
//  
//

import UIKit
import SDWebImage

class CertificateDetailVC: UIViewController
{
    
    var certidata = NSDictionary()
    
    
    
    @IBOutlet weak var lblCertificateTitle: UILabel!
    
    @IBOutlet weak var lblCertificateDescription: UILabel!
    
    
    @IBOutlet weak var imgCertificate: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
//        imgDoctor.sd_setImage(with: URL(string: (dic["image"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)

        
        lblCertificateTitle.text = (certidata["name"] as! String)
        
        imgCertificate.sd_setImage(with: URL(string: (certidata["certificate"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
        lblCertificateDescription.text = (certidata["description"] as! String)
        
    }
    
    @IBAction func btnBack(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }


}


