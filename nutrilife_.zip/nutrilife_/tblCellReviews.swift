//
//  tblCellReviews.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 01/11/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class tblCellReviews: UITableViewCell
{
    
    //--------------------------------
    // MARK: Outlets
    //--------------------------------
    
    @IBOutlet weak var lblReviewTitle: UILabel!
    
    @IBOutlet weak var lblDescription: UILabel!
    
    @IBOutlet weak var imgUser: UIImageView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
