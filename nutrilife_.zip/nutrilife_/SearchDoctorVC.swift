//
//  SearchDoctorVC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 30/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD

class SearchDoctorVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    
    //---------------------------------
    // MARK: Outlets
    //---------------------------------
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var tblDoctors: UITableView!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    //---------------------------------
    // MARK: Identifiers
    //---------------------------------
    
    var doctorData = NSMutableArray()
    var timer = Timer()
    var servicename = String()

    
    //---------------------------------
    // MARK: View Life Cycle
    //---------------------------------

    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        lblTitle.text! = servicename
        doctorlist()
    }
    
    //---------------------------------
    // MARK: Delegate Methods
    //---------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return doctorData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let obj = tblDoctors.dequeueReusableCell(withIdentifier: "tblCellSearchDoctor") as! tblCellSearchDoctor
        let dic = doctorData[indexPath.row] as! NSDictionary
        
        obj.lblDoctorName.text! = (dic["doc_name"] as! String)
        if (dic["doc_address"] as! String) == "null"
        {
             obj.lblDoctorAddress.isHidden = true
        }
        else
        {
            obj.lblDoctorAddress.text! = (dic["doc_address"] as! String)
        }
            
        
        
        obj.lblPackageDetails.text = "There are "+String(dic["total_packages"] as! Int)+" packages of this doctor."
        
        return obj
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let obj = storyboard?.instantiateViewController(withIdentifier: "DoctorDetailsVC") as! DoctorDetailsVC
        let dic = doctorData[indexPath.row] as! NSDictionary
        obj.iddoc = (dic["doc_id"] as! Int)
        navigationController?.pushViewController(obj, animated: true)
    }
    
    //---------------------------------
    // MARK: User Defined Functions
    //---------------------------------
    
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            doctorlist()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    //---------------------------------
    // MARK: Button Actions
    //---------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    
    //---------------------------------
    // MARK: Web Services
    //---------------------------------
    
    
//    http://35.187.227.141/api/patient/service_doctors
    
    
    
//    "{
//    ""service_id"":2
//}"
    
//
//    "{
//    ""msg"": ""List of Doctor's in service"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""service_name"": ""Service 2"",
//    ""service_id"": 2,
//    ""doctor_name"": ""Shreeraj Jadeja"",
//    ""doctor_id"": 3,
//    ""ratings"": 3.5,
//    ""total_packages"": 2
//    }
//    ]
//}"
    
    
    
    
    
    
    func doctorlist()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId"),"service_id" : serviceid] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "patient/service_doctors" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("List of Doctor's in service")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {

                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            self.doctorData = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblDoctors.reloadData()
                            SVProgressHUD.dismiss()
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }

}
