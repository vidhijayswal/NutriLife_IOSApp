//
//  MyDoctorSubDetailsVC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 31/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD

class MyDoctorSubDetailsVC: UIViewController
{
    
    //-----------------------------------
    // MARK: Outlets
    //-----------------------------------
    
    
    
    @IBOutlet weak var lblLocation: UILabel!
    
    @IBOutlet weak var lblEmail: UILabel!
    
    @IBOutlet weak var lblDOB: UILabel!
    
    @IBOutlet weak var lblTotalEarned: UILabel!
    
    @IBOutlet weak var lblTotalPatient: UILabel!
    
    
    
    
    
    //-----------------------------------
    // MARK: Identifiers
    //-----------------------------------
    
    var timer = Timer()
    
    //-----------------------------------
    // MARK: View Life Cycle
    //-----------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()

        viewdoctorprofile()
        
    }
    

    //-----------------------------------
    // MARK: Delegate Methods
    //-----------------------------------
    
    
    
    
    //-----------------------------------
    // MARK: User Defined Functions
    //-----------------------------------
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            viewdoctorprofile()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet is Not Available")
        }
    }
    
    
    //-----------------------------------
    // MARK: Button Actions
    //-----------------------------------
    
    @IBAction func btnCertificateTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "CertificateVC") as! CertificateVC
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    @IBAction func btnReviewTUI(_ sender: UIButton)
    {
        
        let obj = storyboard?.instantiateViewController(withIdentifier: "ReviewsVC") as! ReviewsVC
        navigationController?.pushViewController(obj, animated: true)
    }
    
    //-----------------------------------
    // MARK: Web Services
    //-----------------------------------

    
    
    
    
    
    
//    http://35.187.227.141/api/doctor/profile
    
    
    
//    "{
//    ""doc_id"":3
//}"
    
    
    
    
//    "{
//    ""msg"": ""Doctor's profile details"",
//    ""status"": 1,
//    ""data"": {
//    ""fname"": ""Shreeraj"",
//    ""lname"": ""Jadeja"",
//    ""image"": ""http://http://35.187.227.141/storage/uploads/sgm2_1540893810.png"",
//    ""email"": ""shreeraj.qrioustech@gmail.com"",
//    ""availability"": 1,
//    ""dob"": ""1993-04-17"",
//    ""address"": ""Ahmedabad"",
//    ""reviews"": 1,
//    ""certificates"": 1
//    }
//}"
    
    
    
    
    
    func viewdoctorprofile()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : id] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/profile" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Doctor's profile details")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                            
                            let data = result["data"] as! NSDictionary

                            
                            self.lblLocation.text = "Location: "+(data["address"] as! String)
                            self.lblEmail.text = "Email: "+(data["email"] as! String)
                            
                            self.lblDOB.text = "DOB: "+(data["dob"] as! String)
                            
                            self.lblTotalEarned.text = "Total Earned: "+(String(data["total_earned"] as! Int))
                            
                            self.lblTotalPatient.text = "Total Patients: "+String(data["number_of_patients"] as! Int)
                            
        
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
}
