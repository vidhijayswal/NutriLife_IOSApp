//
//  BookDetailsVC.swift
//  NutriLife
//
//  
//

import UIKit

class BookDetailsVC: UIViewController
{
    
    //--------------------------------
    // MARK: Outlets
    //--------------------------------
    
    @IBOutlet weak var lblBookTitle: UILabel!
    
    @IBOutlet weak var lblReadersCount: UILabel!
    
    @IBOutlet weak var ImgBook: UIImageView!
    
    @IBOutlet weak var txtDescription: UITextView!
    
    //--------------------------------
    // MARK: Identifiers
    //--------------------------------
    
    var book = NSDictionary()
    
    //--------------------------------
    // MARK: View Life Cycle
    //--------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        lblBookTitle.text! = (book["book_name"] as! String)
        lblReadersCount.text! = String(book["readers"] as! Int)
        txtDescription.text! = (book["description"] as! String)
        ImgBook.sd_setImage(with: URL(string: (book["book"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)


        
    }
    

    //--------------------------------
    // MARK: Delegate Methods
    //--------------------------------
    
    
    
    //--------------------------------
    // MARK: User Defined Functions
    //--------------------------------
    
    
    
    //--------------------------------
    // MARK: Button Actions
    //--------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    //--------------------------------
    // MARK: Web Services
    //--------------------------------

}
