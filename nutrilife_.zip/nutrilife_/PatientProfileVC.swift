//
//  PatientProfileVC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 02/11/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD
import HCSStarRatingView
import SDWebImage
import CoreLocation
import GoogleMaps
import GooglePlaces

class PatientProfileVC: UIViewController, UITextFieldDelegate
{
    
    //----------------------------------
    // MARK: Outlets
    //----------------------------------
    
    @IBOutlet weak var imgUser: UIImageView!
    
    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var lblFirstNameError: UILabel!
    
    @IBOutlet weak var txtLastName: UITextField!
    
    @IBOutlet weak var lblLastNameError: UILabel!
    
    @IBOutlet weak var txtLocation: UITextField!
    
    @IBOutlet weak var lblLocationError: UILabel!
    
    @IBOutlet weak var lblDOB: UILabel!
    
    @IBOutlet weak var lblEmail: UILabel!
    
    @IBOutlet weak var lblTotalSpent: UILabel!
    
    @IBOutlet weak var lblServicesUsed: UILabel!
    
    @IBOutlet weak var lblReviewsGiven: UILabel!
    
    @IBOutlet weak var lblBMI: UILabel!
    
    //----------------------------------
    // MARK: Identifiers
    //----------------------------------
    
    var timer = Timer()
    var patientprofile =  NSDictionary()
    
    //----------------------------------
    // MARK: View Life Cycle
    //----------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()

        lblFirstNameError.isHidden = true
        lblLastNameError.isHidden = true
        lblLocationError.isHidden = true
        
        txtFirstName.delegate = self
        txtLastName.delegate = self
        txtLocation.delegate = self
        
        txtFirstName.isEnabled = false
        txtLastName.isEnabled = false
        txtLocation.isEnabled = false
        
        
        imgUser.layer.cornerRadius = imgUser.frame.size.width / 2
        imgUser.clipsToBounds = true
        
        
    }
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        viewpatientprofile()
    }

    
    //----------------------------------
    // MARK: Delegate Methods
    //----------------------------------
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        self.view.endEditing(true)
        return true
    }
    
    //----------------------------------
    // MARK: User Defined Functions
    //----------------------------------
    
    @objc func txtFirstNameValueChanged()
    {
        if txtFirstName.text == ""
        {
            lblFirstNameError.isHidden = false
        }
        else
        {
            lblFirstNameError.isHidden = true
        }
    }
    
    @objc func txtLastNameValueChanged()
    {
        if txtLastName.text == ""
        {
            lblLastNameError.isHidden = false
        }
        else
        {
            lblLastNameError.isHidden = true
        }
    }
    
    @objc func txtLocationValueChanged()
    {
        if txtLocation.text == ""
        {
            lblLocationError.isHidden = false
        }
        else
        {
            lblLocationError.isHidden = true
        }
    }
    
    
    
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            viewpatientprofile()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet is Not Available")
        }
    }
    
    //----------------------------------
    // MARK: Button Actions
    //----------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func btnEdit(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "EditProfileVC") as! EditProfileVC
        
        obj.patientprofile = self.patientprofile
        
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    @IBAction func btnRecalculateBMI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "BMIVC") as! BMIVC
        
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    
    //----------------------------------
    // MARK: Web Services
    //----------------------------------
    
    
    
    
//    http://35.187.227.141/api/patient/profile
   
    
    
    
    
//    "{
//    ""patient_id"":4
//}"
    
    
    
    
    
//    "{
//    ""msg"": ""Patient's Profile"",
//    ""status"": 1,
//    ""data"": {
//    ""fname"": ""Sulay"",
//    ""lname"": ""Panchal"",
//    ""email"": ""sulay.qrioustech@gmail.com"",
//    ""image"": ""http://localhost/nutrilife/storage/uploads/sgm_1540893496.png"",
//    ""dob"": ""1993-02-01"",
//    ""address"": ""Ahmedabad"",
//    ""reviews_given"": 3,
//    ""bmi"": 9.7,
//    ""total_spent"": ""$75"",
//    ""services_used"": 1
//    }
//}"
    
    
    
    func viewpatientprofile()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["patient_id" : UserDefaults.standard.integer(forKey: "userId")  ] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "patient/profile" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Patient's Profile")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                            
                            let data = result["data"] as! NSDictionary
                            self.patientprofile = result["data"] as! NSDictionary
                            self.imgUser.sd_setImage(with: URL(string: (data["image"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
                            
                            
                            self.txtFirstName.text = (data["fname"] as! String)
                            self.txtLastName.text = (data["lname"] as! String)
                            
                            self.txtLocation.text = (data["address"] as! String)
                            
                            // self.availableSwitch.isOn = (data["availability"] as! Int)
                            
                            
                            self.lblDOB.text = "DOB: "+((data["dob"] as! String))
                            
                            self.lblEmail.text = "Email: "+(data["email"] as! String)
                            
                           // self.ratingsStar.value = CGFloat((data["reviews"] as! Int))
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }

}
