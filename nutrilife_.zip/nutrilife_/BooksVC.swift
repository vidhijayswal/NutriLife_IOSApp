//
//  BooksVC.swift
//  NutriLife
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD
import SDWebImage

class BooksVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    
    //-------------------------
    // MARK: Outlets
    //-------------------------
    
    @IBOutlet weak var tblBook: UITableView!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var btnAdd: UIButton!
    
    @IBOutlet weak var lblTitle: UILabel!
    //-------------------------
    // MARK: Identifiers
    //-------------------------
    
    var timer = Timer()
    
    var doctorbookdata = NSMutableArray()
    
    var doc_book_id = Int()
    
    
    


    //-------------------------
    // MARK: View Life Cycle
    //-------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        

        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            lblTitle.text = "My Books"
            btnAdd.isHidden = false
            books()
        }
        else
        {
            lblTitle.text = "Books"
            btnAdd.isHidden = true
            patientbooks()
        }
    }
    
   
    
    
    //-------------------------
    // MARK: Delegate Methods
    //-------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return doctorbookdata.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let obj = tblBook.dequeueReusableCell(withIdentifier: "tblCellBooks") as! tblCellBooks
        let dic = doctorbookdata[indexPath.row] as! NSDictionary
        
        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            obj.imgBook.sd_setImage(with: URL(string: (dic["book"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
            obj.lblBookName.text = (dic["book_name"] as! String)
            obj.lblBookDescription.text = (dic["description"] as! String)
           // obj.lblStatus.text = (dic["status"] as! String)
            obj.bookSwitch.layer.cornerRadius = obj.bookSwitch.frame.height/2
            obj.bookSwitch.isHidden = false
            
            
            if (dic["status"] as! Int) == 0
            {
                obj.bookSwitch.isOn = false
            }
            else
            {
                obj.bookSwitch.isOn = true
            }
            obj.bookSwitch.tag = (dic["doc_book_id"] as! Int)
        }
        else
        {
            obj.imgBook.sd_setImage(with: URL(string: (dic["book"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
            obj.lblBookName.text = (dic["book_name"] as! String)
            obj.lblBookDescription.text = (dic["description"] as! String)
            // obj.lblStatus.text = (dic["status"] as! String)
            obj.bookSwitch.isHidden = true
        }
        
        return obj
    }
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let dic = doctorbookdata[indexPath.row] as! NSDictionary
        let obj = storyboard?.instantiateViewController(withIdentifier: "BookDetailsVC") as! BookDetailsVC
         obj.book = dic
        navigationController?.pushViewController(obj, animated: true)
    }
    
    //-------------------------------
    // MARK: User Defined Functions
    //-------------------------------
    
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            books()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    



                
                
                
    //-------------------------
    // MARK: Button Actions
    //-------------------------
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnAddTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "AddBookVC") as! AddBookVC
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    @IBAction func btnbookvisibility(_ sender: UISwitch)
    {
        doc_book_id = sender.tag
        bookvisibility()
    }
    
    
    
    
    //-------------------------
    // MARK: Web Services
    //-------------------------

    
//    http://35.187.227.141/api/doctor/books
    
    
//    "{
//    ""doc_id"":3
//}"

    
//    "{
//    ""msg"": ""1 books available"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""doc_book_id"": 1,
//    ""name"": ""How to become a great doctor?"",
//    ""book"": ""http://35.187.227.141/storage/uploads/Introforapp_1540454367.m4a"",
//    ""description"": ""Lorem Ipsum is simply dummy tehdhsjwiebsbsjajjekekwjxt of ruruueieiei3ihshshhsusushdhdhdjdjdjsjsjthe prsbsjdjsbsjsjjinting and typesetting industry"",
//    ""readers"": 146,
//    ""status"": 1
//    }
//    ]
//}"
    
    
    
    
    
    func books()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId")] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/books" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("1 books available")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            
                            self.doctorbookdata = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblBook.reloadData()
                            SVProgressHUD.dismiss()
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
            
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    
    
//    http://35.187.227.141/api/doctor/book_status
    
    
    
//    "{
//    ""doc_book_id"":1
//}"
    
    
//    "{
//    ""msg"": ""Success! Book visibility changed"",
//    ""status"": 1,
//    ""visibility"": 1
//}"
    
    
    
    
    func bookvisibility()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_book_id" : doc_book_id ] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/book_status" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Success! Book visibility changed")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    
    
    
//    http://35.187.227.141/api/patient/allbooks
    
    
    
    
//    None
    
    
    
    
//    "{
//    ""msg"": ""2 books available"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""book_id"": 1,
//    ""doctor"": ""Shreeraj Jadeja"",
//    ""book_name"": ""How to become a great doctor?"",
//    ""readers"": 3,
//    ""book"": ""http://http://35.187.227.141/storage/uploads/Introforapp_1540454367.m4a"",
//    ""description"": ""Lorem Ipsum is simply dummy text of the printing and typesetting industry""
//    },
//    {
//    ""book_id"": 2,
//    ""doctor"": ""Shreeraj Jadeja"",
//    ""book_name"": ""How to be a good doctor?"",
//    ""readers"": 5,
//    ""book"": ""http://http://35.187.227.141/storage/uploads/08NaJaPagalWorldinfo_1540458411.mp3"",
//    ""description"": ""Lorem Ipsum is simply dummy text of the printing and typesetting industry""
//    }
//    ]
//}"
    
    
    
    
    
    func patientbooks()
        
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "patient/allbooks" , method: .get, parameters: nil, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("2 books available")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            
                            self.doctorbookdata = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblBook.reloadData()
                            SVProgressHUD.dismiss()
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
            
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    
}
