//
//  AddGoalsVC.swift
//  NutriLife
//
//  
//

import UIKit
import SVProgressHUD
import Alamofire


class AddGoalsVC: UIViewController,UITextFieldDelegate, UITextViewDelegate
{

    
    //----------------------------
    // MARK: Outlets
    //----------------------------
    
    @IBOutlet weak var txtTitle: UITextField!
    
    @IBOutlet weak var lblTitleError: UILabel!
    
    @IBOutlet weak var txtDescription: UITextView!
    
    @IBOutlet weak var lblDescriptionError: UILabel!
    //----------------------------
    // MARK: Identifiers
    //----------------------------
    
    var timer = Timer()
    
    //----------------------------
    // MARK: View Life Cycle
    //----------------------------
    override func viewDidLoad() {
        super.viewDidLoad()

        lblTitleError.isHidden = true
        lblDescriptionError.isHidden = true
        
        txtTitle.delegate = self
        txtDescription.delegate = self
        
        txtDescription.layer.cornerRadius = 5
        txtDescription.layer.borderColor = UIColor.lightGray.cgColor
        txtDescription.layer.borderWidth = 1
    
        txtTitle.addTarget(self, action: #selector(txtTitleValueChanged), for: .editingChanged)
    
    }
    
    
    //----------------------------
    // MARK: Delegate Methods
    //----------------------------
    
    func textViewDidChange(_ textView: UITextView) {
        if txtDescription.text == ""
        {
            lblDescriptionError.isHidden = false
        }
        else
        {
            lblDescriptionError.isHidden = true
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        self.view.endEditing(true)
        return true
    }
    
    //----------------------------
    // MARK: User Defined Functions
    //----------------------------
    
    @objc func txtTitleValueChanged()
    {
        if txtTitle.text == ""
        {
            lblTitleError.isHidden = false
        }
        else
        {
            lblTitleError.isHidden = true
        }
    }
    
    
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            addgoal()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    //----------------------------
    // MARK: Button Actions
    //----------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    //----------------------------
    // MARK: Web Services
    //----------------------------
    
    
    
//    http://35.187.227.141/api/doctor/addgoal
    
//    "{
//    ""service_id"":2,
//    ""doc_id"":3,
//    ""patient_id"":4,
//    ""title"":""Breakfast details"",
//    ""instruction"":""Take your breakfast before 10 AM""
//}"

    
    
    
//    "{
//    ""msg"": ""Goal/Intruction added for patient."",
//    ""status"": 1
//}"
    
    
    
    
    func addgoal()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["service_id": serviceid, "patient_id": id, "doc_id" : UserDefaults.standard.integer(forKey: "userId"), "title": txtTitle.text!, "instruction": txtDescription.text!, "package_id": packageid ] as [String : Any]
        
//        , "package_id": , "title": 
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/addgoal" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Goal added for patient.")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                           
                            SVProgressHUD.dismiss()
                            PopUp(Controller: self, title: "Message", message: (result["msg"] as! String))
                            
                            let obj = self.storyboard?.instantiateViewController(withIdentifier: "GoalsAndPaymentVC") as! GoalsAndPaymentVC
                            
                            self.navigationController?.pushViewController(obj, animated: true)
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
            
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    
}
