//
//  ServicesPatientSideVC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 30/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD

class ServicesPatientSideVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    
    
    //-------------------------------
    // MARK: Outlets
    //-------------------------------

    @IBOutlet weak var tblServices: UITableView!
    
    
    //-------------------------------
    // MARK: Identifiers
    //-------------------------------
    
    var PatientServiceData = NSMutableArray()
    var timer = Timer()
    
    //-------------------------------
    // MARK: View Life Cycle
    //-------------------------------
    override func viewDidLoad()
    {
        super.viewDidLoad()
        servicesAvailable()

    }
    

    //-------------------------------
    // MARK: Delegate Methods
    //-------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PatientServiceData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let obj = tblServices.dequeueReusableCell(withIdentifier: "tblCellServicesPatientSIde") as! tblCellServicesPatientSIde
        let dic = PatientServiceData[indexPath.row] as! NSDictionary
        
        
        obj.lblServiceName.text! = (dic["service_name"] as! String)
        obj.lblDoctorNumber.text! = "Doctors: "+String(dic["total_doctors"] as! Int)
        obj.lblPackageNumber.text! = "Packages: "+String(dic["total_packages"] as! Int)
        
        return obj
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "SearchDoctorVC") as! SearchDoctorVC
        let dic = PatientServiceData[indexPath.row] as! NSDictionary
        serviceid = (dic["service_id"] as! Int)
        obj.servicename = (dic["service_name"] as! String)
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    //-------------------------------
    // MARK: User Defined Functions
    //-------------------------------
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            servicesAvailable()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    //-------------------------------
    // MARK: Button Actions
    //-------------------------------
    
    
    
    
    //-------------------------------
    // MARK: Web Services
    //-------------------------------
    
//   http://35.187.227.141/api/patient/services
    
    
//    None
    
    
    
    
    
    
//    "{
//    ""msg"": ""6 services available"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""service_id"": 1,
//    ""name"": ""Service 1"",
//    ""total_packages"": 2,
//    ""total_doctors"": 1
//    },
//    {
//    ""service_id"": 2,
//    ""name"": ""Service 2"",
//    ""total_packages"": 0,
//    ""total_doctors"": 0
//    },
//    {
//    ""service_id"": 3,
//    ""name"": ""Service 3"",
//    ""total_packages"": 0,
//    ""total_doctors"": 0
//    },
//    {
//    ""service_id"": 4,
//    ""name"": ""Service 4"",
//    ""total_packages"": 0,
//    ""total_doctors"": 0
//    },
//    {
//    ""service_id"": 5,
//    ""name"": ""Service 5"",
//    ""total_packages"": 0,
//    ""total_doctors"": 0
//    },
//    {
//    ""service_id"": 6,
//    ""name"": ""Service 6"",
//    ""total_packages"": 0,
//    ""total_doctors"": 0
//    }
//    ]
//}"
    
    
    
  
    
    func servicesAvailable()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "patient/services" , method: .get, parameters: nil, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("6 services available")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            self.PatientServiceData = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblServices.reloadData()
                            SVProgressHUD.dismiss()
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    
    
}


