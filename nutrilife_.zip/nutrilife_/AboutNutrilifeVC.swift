//
//  AboutNutrilifeVC.swift
//  NutriLife
//
//

import UIKit
import Alamofire
import SVProgressHUD

extension Data
{
    var html2AttributedString: NSAttributedString?
    {
        do
        {
            return try NSAttributedString(data: self, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding: String.Encoding.utf8.rawValue], documentAttributes: nil)
        }
        catch
        {
            print("error:", error)
            return  nil
        }
    }
    var html2String: String
    {
        return html2AttributedString?.string ?? ""
    }
}

extension String
{
    var html2AttributedString: NSAttributedString?
    {
        return Data(utf8).html2AttributedString
    }
    var html2String: String
    {
        return html2AttributedString?.string ?? ""
    }
}



class AboutNutrilifeVC: UIViewController
{

    
    //----------------------------------
    // MARK: Outlets
    //----------------------------------
    
    @IBOutlet weak var lblShortDescription: UILabel!
    
    @IBOutlet weak var lblMission: UILabel!
    
    @IBOutlet weak var lblVision: UILabel!
    
    @IBOutlet weak var scrollingViewHeight: NSLayoutConstraint!
    //----------------------------------
    // MARK: Identifiers
    //----------------------------------
    
    var timer = Timer()
    
    //----------------------------------
    // MARK: View Life Cycle
    //----------------------------------
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        about()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool)
    {
        scrollingViewHeight.constant = 320 + lblShortDescription.frame.height + lblMission.frame.height + lblVision.frame.height
    }
    
    //----------------------------------
    // MARK: Delegate Methods
    //----------------------------------
    
    
    //----------------------------------
    // MARK: User Defined Functions
    //----------------------------------
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            about()
            
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    //----------------------------------
    // MARK: Button Actions
    //----------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    //----------------------------------
    // MARK: Web Services
    //----------------------------------
    
    
    func about()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            Alamofire.request( appDelegate.apiString + "aboutus", method: .get, parameters: nil, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("About Nutrilife")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            SVProgressHUD.dismiss()
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            let info = result["data"] as! NSDictionary
        
                            self.lblShortDescription.text = (info["description"] as! String).html2String
                            self.lblMission.text = (info["mission"] as! String).html2String
                            self.lblVision.text = (info["vision"] as! String).html2String
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }

}
