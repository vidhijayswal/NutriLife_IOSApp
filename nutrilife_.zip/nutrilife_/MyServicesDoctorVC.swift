//
//  MyServicesDoctorVC.swift
//  NutriLife
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD

class MyServicesDoctorVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    
    
    //-------------------------------
    // MARK: Outlets
    //-------------------------------

    @IBOutlet weak var tblServices: UITableView!
    
    @IBOutlet weak var btnNext: UIButton!
    
    //-------------------------------
    //MARK: Identifiers
    //-------------------------------
    
    
    
    var doctorServiceData = NSMutableArray()
    
     var timer = Timer()
    
    //-------------------------------
    // MARK: View Life Cycle
    //-------------------------------

    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        myservices()

        btnNext.isHidden = true
    
        // Do any additional setup after loading the view.
    }
    
    //-------------------------------
    // MARK: Delegate Methods
    //-------------------------------

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return doctorServiceData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let obj = tblServices.dequeueReusableCell(withIdentifier: "tblCellMyServicesDoctor") as! tblCellMyServicesDoctor
        
        obj.serviceSwitch.layer.cornerRadius = obj.serviceSwitch.frame.height/2
        let dic = doctorServiceData[indexPath.row] as! NSDictionary
        if (dic["status"] as! Int) == 0
        {
            obj.serviceSwitch.isOn = false
        }
        else
        {
            obj.serviceSwitch.isOn = true
        }
        
        obj.lblServiceName.text = (dic["service_name"] as! String)
        obj.serviceSwitch.tag = (dic["service_id"] as! Int)
        
        return obj
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
        let dic = doctorServiceData[indexPath.row] as! NSDictionary
        if (dic["status"] as! Int) == 1
        {
            let obj = storyboard?.instantiateViewController(withIdentifier: "AddPackageVC") as! AddPackageVC

            serviceid = (dic["service_id"] as! Int)
            navigationController?.pushViewController(obj, animated: true)
        }
        
        else
        {
            PopUp(Controller: self, title: "Alert", message: "You need to active this service before adding package to it.")
        }
        
        
    }
    

    
    //-------------------------------
    // MARK: Button action
    //-------------------------------
    
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnServicesAvailable(_ sender: UISwitch)
    {
        serviceid = sender.tag
        ServiceVisibility()
    }
    
    
    
    
    //-------------------------------
    // MARK: user defined functions
    //-------------------------------
    
    @objc func InternetAvailable()
    {
        if Connectivity.isConnectedToInternet()
        {
            myservices()
        }
        else
        {
            SVProgressHUD.dismiss()
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    //-------------------------------
    // MARK: Web Services
    //-------------------------------
    
    
    
//    http://35.187.227.141/api/doctor/docservices
    
    
//    "{
//    ""doc_id"":3
//}"

    
//    "{
//    ""msg"": ""Services List!"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""doc_service_id"": 1,
//    ""service_id"": 1,
//    ""service_name"": ""Service 1"",
//    ""doc_id"": 3,
//    ""status"": 0,
//    ""created_at"": ""2018-10-30 12:49:42"",
//    ""updated_at"": ""2018-10-30 12:49:42""
//    },
//    {
//    ""doc_service_id"": 2,
//    ""service_id"": 2,
//    ""service_name"": ""Service 2"",
//    ""doc_id"": 3,
//    ""status"": 0,
//    ""created_at"": ""2018-10-30 12:49:42"",
//    ""updated_at"": ""2018-10-30 12:49:42""
//    },
//    {
//    ""doc_service_id"": 3,
//    ""service_id"": 3,
//    ""service_name"": ""Service 3"",
//    ""doc_id"": 3,
//    ""status"": 0,
//    ""created_at"": ""2018-10-30 12:49:42"",
//    ""updated_at"": ""2018-10-30 12:49:42""
//    },
//    {
//    ""doc_service_id"": 4,
//    ""service_id"": 4,
//    ""service_name"": ""Service 4"",
//    ""doc_id"": 3,
//    ""status"": 0,
//    ""created_at"": ""2018-10-30 12:49:42"",
//    ""updated_at"": ""2018-10-30 12:49:42""
//    },
//    {
//    ""doc_service_id"": 5,
//    ""service_id"": 5,
//    ""service_name"": ""Service 5"",
//    ""doc_id"": 3,
//    ""status"": 0,
//    ""created_at"": ""2018-10-30 12:49:42"",
//    ""updated_at"": ""2018-10-30 12:49:42""
//    },
//    {
//    ""doc_service_id"": 6,
//    ""service_id"": 6,
//    ""service_name"": ""Service 6"",
//    ""doc_id"": 3,
//    ""status"": 0,
//    ""created_at"": ""2018-10-30 12:49:42"",
//    ""updated_at"": ""2018-10-30 12:49:42""
//    }
//    ]
//}"
    

    func myservices()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId")] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/docservices" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Services List!")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            self.doctorServiceData = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblServices.reloadData()
                            SVProgressHUD.dismiss()
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    
    
//    http://35.187.227.141/api/doctor/servicestatus
    
    
//    "{
//    ""doc_id"":3,
//    ""service_id"":2
//}"
    
    
//    "{
//    ""msg"": ""Service Active"",
//    ""status"": 1
//}"
    
    
    
    func ServiceVisibility()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId"), "service_id" : serviceid] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/servicestatus" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Service Active")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
}

