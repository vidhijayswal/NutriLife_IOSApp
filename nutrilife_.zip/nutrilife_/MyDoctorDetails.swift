//
//  MyDoctorDetails.swift
//  NutriLife
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD
import SDWebImage

class MyDoctorDetails: UIViewController
{
    
    //---------------------------------
    // MARK: Outlets
    //---------------------------------
    
    @IBOutlet weak var imgDoctor: UIImageView!
    
    @IBOutlet weak var lblDoctorName: UILabel!
    
    @IBOutlet weak var lblServiceName: UILabel!
    
    @IBOutlet weak var lblStatus: UILabel!
    
    @IBOutlet weak var tabbarView: UIView!
    
    @IBOutlet weak var btnDetails: UIButton!
    
    @IBOutlet weak var btnPayments: UIButton!
    
    @IBOutlet weak var btnGoals: UIButton!
    
    @IBOutlet weak var containerView: UIView!
    
    @IBOutlet weak var lblTitle: UILabel!
    
    
    //---------------------------------
    // MARK: Identifiers
    //---------------------------------
    
    var DoctorDetailsVC = UIViewController()
    var doctorPatientData = NSMutableArray()
    var docData = NSDictionary()
    
    //---------------------------------
    // MARK: View Life Cycle
    //---------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()

        tabbarView.layer.borderWidth = 1
        tabbarView.layer.borderColor = UIColor.lightGray.cgColor
        btnDetails.isSelected = true
        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            
            imgDoctor.sd_setImage(with: URL(string: (docData["image"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
            lblDoctorName.text = (docData["patient_name"] as! String)
            lblServiceName.text = (docData["service_name"] as! String)
            lblStatus.text = (docData["status"] as! String)
            
            
            
            lblTitle.text = "Patient Details"

            DoctorDetailsVC = storyboard?.instantiateViewController(withIdentifier: "MyPetientDetailsVC") as! MyPetientDetailsVC
        }
        else
        {
            lblTitle.text = "Doctor Details"
            lblDoctorName.text = (docData["doc_name"] as! String)
            lblServiceName.text = (docData["service_name"] as! String)
            lblStatus.text = (docData["status"] as! String)
            imgDoctor.sd_setImage(with: URL(string: (docData["image"] as! String)), placeholderImage: UIImage(named: "img_user"), options: .refreshCached, completed: nil)
            DoctorDetailsVC = storyboard?.instantiateViewController(withIdentifier: "MyDoctorSubDetailsVC") as! MyDoctorSubDetailsVC
        }
        
        
        self.addChild(DoctorDetailsVC)
        DoctorDetailsVC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
        self.containerView.addSubview(DoctorDetailsVC.view)
        DoctorDetailsVC.didMove(toParent: self)
        NotificationCenter.default.addObserver(self, selector: #selector(DoctorDetailsChangeVC), name: Notification.Name("DoctorDetailsVcChanged"), object: nil)
        
        // Do any additional setup after loading the view.
    }
    
    //---------------------------------
    // MARK: Delegate Methods
    //---------------------------------
    
    
    
    //---------------------------------
    // MARK: User Defined Functions
    //---------------------------------
    
    @objc func DoctorDetailsChangeVC(_notification: Notification)
    {
        DoctorDetailsVC.view.removeFromSuperview()
        
        switch (_notification.userInfo!["Id"] as! String)
        {
            
        case "MyPetientDetailsVC":
            DoctorDetailsVC = storyboard?.instantiateViewController(withIdentifier: "MyPetientDetailsVC") as! MyPetientDetailsVC
            
        case "MyDoctorSubDetailsVC":
            DoctorDetailsVC = storyboard?.instantiateViewController(withIdentifier: "MyDoctorSubDetailsVC") as! MyDoctorSubDetailsVC
            
        case "GoalsAndPaymentVC":
            DoctorDetailsVC = storyboard?.instantiateViewController(withIdentifier: "GoalsAndPaymentVC") as! GoalsAndPaymentVC
        case "NotificationVC":
            DoctorDetailsVC = storyboard?.instantiateViewController(withIdentifier: "NotificationVC") as! NotificationVC
        default:
            print("")
        }
        self.addChild(DoctorDetailsVC)
        DoctorDetailsVC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
        self.containerView.addSubview(DoctorDetailsVC.view)
        DoctorDetailsVC.didMove(toParent: self)
    }
    

    
    
    //---------------------------------
    // MARK: Button Actions
    //---------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnDetailsTUI(_ sender: UIButton)
    {
        if !btnDetails.isSelected
        {
            if UserDefaults.standard.string(forKey: "userrole") == "doctor"
            {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "DoctorDetailsVcChanged"), object: nil, userInfo: ["Id": "MyPetientDetailsVC"])
            }
            else
            {
               NotificationCenter.default.post(name: NSNotification.Name(rawValue: "DoctorDetailsVcChanged"), object: nil, userInfo: ["Id": "MyDoctorSubDetailsVC"])
                
            }
            
            
            btnDetails.isSelected = true
            btnGoals.isSelected = false
            btnPayments.isSelected = false
        }
    }
    
    @IBAction func btnGoalsTUI(_ sender: UIButton)
    {
        if !btnGoals.isSelected
        {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "DoctorDetailsVcChanged"), object: nil, userInfo: ["Id": "GoalsAndPaymentVC"])
            currentVC = "Goals"
            btnGoals.isSelected = true
            btnDetails.isSelected = false
            btnPayments.isSelected = false
        }
    }
    
    @IBAction func btnPaymentTUI(_ sender: UIButton)
    {
        if !btnPayments.isSelected
        {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "DoctorDetailsVcChanged"), object: nil, userInfo: ["Id": "GoalsAndPaymentVC"])
            currentVC = "Payment"
            btnPayments.isSelected = true
            btnGoals.isSelected = false
            btnDetails.isSelected = false
        }
    }

}
