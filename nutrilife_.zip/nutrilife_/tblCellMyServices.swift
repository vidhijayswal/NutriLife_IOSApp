//
//  tblCellMyServices.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 31/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class tblCellMyServices: UITableViewCell
{
    //------------------------------
    // MARK: Outlets
    //------------------------------
    
    @IBOutlet weak var lblServiceName: UILabel!
    
    @IBOutlet weak var lblDoctorName: UILabel!
    
    @IBOutlet weak var lblStatus: UILabel!
    
    @IBOutlet weak var lblPackageName: UILabel!
    
    @IBOutlet weak var lblPackagePrice: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
