//
//  AddBookVC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 02/11/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit
import RichEditorView

class AddBookVC: UIViewController, UITextFieldDelegate, UITextViewDelegate, RichEditorDelegate, RichEditorToolbarDelegate
{

    //------------------------------
    // MARK: Outlets
    //------------------------------
    
    @IBOutlet weak var txtTitle: UITextField!
    
    @IBOutlet weak var lblTitleError: UILabel!
    
    @IBOutlet weak var txtDescription: UITextView!
    
    @IBOutlet weak var lblDescriptionError: UILabel!
    
    @IBOutlet weak var visibleSwitch: UISwitch!
    //------------------------------
    // MARK: Identifiers
    //------------------------------
    
    
    
    
    //------------------------------
    // MARK: View Life Cycle
    //------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblTitleError.isHidden = true
        lblDescriptionError.isHidden = true
        visibleSwitch.layer.cornerRadius = visibleSwitch.frame.height/2
        txtDescription.layer.borderColor = UIColor.lightGray.cgColor
        txtDescription.layer.borderWidth = 1
        txtDescription.layer.cornerRadius = 5
        txtDescription.delegate = self
        
        
        txtTitle.delegate = self
        
        
        //txtDescription.addSubview(toolbar)
        
        txtTitle.addTarget(self, action: #selector(txtTitleValueChanged), for: .editingChanged)
        // Do any additional setup after loading the view.
    }
    
    //------------------------------
    // MARK: Delegate Methods
    //------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        self.view.endEditing(true)
        return true
    }
    
    func textViewDidChange(_ textView: UITextView)
    {
        if txtDescription.text == ""
        {
            lblDescriptionError.isHidden = false
        }
        else
        {
            lblDescriptionError.isHidden = true
        }
        
    }
    
    
    //------------------------------
    // MARK: User Defined Functions
    //------------------------------
    
    @objc func txtTitleValueChanged()
    {
        if txtTitle.text == ""
        {
            lblTitleError.isHidden = false
        }
        else
        {
            lblTitleError.isHidden = true
        }
    }
    
    //------------------------------
    // MARK: Button Actions
    //------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    
    //------------------------------
    // MARK: Web Services
    //------------------------------


}
