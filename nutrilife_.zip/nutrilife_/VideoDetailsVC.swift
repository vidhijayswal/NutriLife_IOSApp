//
//  VideoDetailsVC.swift
//  NutriLife
//
//  
//

import UIKit
import WebKit
import Alamofire
import SVProgressHUD


class VideoDetailsVC: UIViewController
{
    
    //--------------------------------
    // MARK: Outlets
    //--------------------------------
    
    @IBOutlet weak var lblVideoTitle: UILabel!
    
    @IBOutlet weak var lblViewCount: UILabel!
    
    @IBOutlet weak var videoWebView: WKWebView!
    
    @IBOutlet weak var txtDescription: UITextView!
    
    
    
    //--------------------------------
    // MARK: Identifiers
    //--------------------------------
    
    var video = NSDictionary()
    
    //--------------------------------
    // MARK: View Life Cycle
    //--------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
    
    
        lblVideoTitle.text! = (video["video_name"] as! String)
        lblViewCount.text! = String(video["views"] as! Int)
        txtDescription.text! = (video["description"] as! String)
        //obj.videoWebView.= "http://35.187.227.141/storage/uploads/fileexampleMP448015MG_1543059407.mp4"

    
    }
    

    //--------------------------------
    // MARK: Delegate Methods
    //--------------------------------
    
    
    
    
    //--------------------------------
    // MARK: User Defined Functions
    //--------------------------------
    
    
    
    //--------------------------------
    // MARK: Button Actions
    //--------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    //--------------------------------
    // MARK: Web Services
    //--------------------------------
    
    

    

    

}
