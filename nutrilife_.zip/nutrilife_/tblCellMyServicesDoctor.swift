//
//  tblCellMyServicesDoctor.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 01/11/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit

class tblCellMyServicesDoctor: UITableViewCell
{
    //-------------------------------
    // MARK: Outlets
    //-------------------------------

    @IBOutlet weak var lblServiceName: UILabel!
    
    
    @IBOutlet weak var serviceSwitch: UISwitch!
    
    

    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
