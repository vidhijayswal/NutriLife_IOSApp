//
//  MNTForm1VC.swift
//  NutriLife
//
//  Created by Ashutosh Jani on 31/10/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD

class MNTForm1VC: UIViewController, UITextFieldDelegate
{
    //-----------------------------
    // MARK: Outlets
    //-----------------------------
    
    @IBOutlet weak var txtHealthStatus: UITextField!
    
    @IBOutlet weak var lblHealthStatusError: UILabel!
    
    @IBOutlet weak var txtBreakfastMorning: UITextField!
    
    @IBOutlet weak var lblBreakfastMorningError: UILabel!
    
    @IBOutlet weak var txtLunch: UITextField!
    
    @IBOutlet weak var lblLunchError: UILabel!
    
    @IBOutlet weak var txtBreakfastEvening: UITextField!
    
    @IBOutlet weak var lblBreakfastEveningError: UILabel!
    
    @IBOutlet weak var txtDinner: UITextField!
    
    @IBOutlet weak var lblDinnerError: UILabel!
    
    @IBOutlet weak var txtOtherHabbits: UITextField!
    
    @IBOutlet weak var lblOtherHabbitsError: UILabel!
    
    @IBOutlet weak var txtMedication: UITextField!
    
    @IBOutlet weak var lblMedicationError: UILabel!
    //-----------------------------
    // MARK: Identifiers
    //-----------------------------
    
    var timer = Timer()
    
    //-----------------------------
    // MARK: View Life Cycle
    //-----------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()

        lblHealthStatusError.isHidden = true
        lblBreakfastMorningError.isHidden = true
        lblLunchError.isHidden = true
        lblBreakfastEveningError.isHidden = true
        lblDinnerError.isHidden = true
        lblMedicationError.isHidden = true
        lblOtherHabbitsError.isHidden = true
        
        txtHealthStatus.delegate = self
        txtBreakfastMorning.delegate = self
        txtBreakfastEvening.delegate = self
        txtLunch.delegate = self
        txtDinner.delegate = self
        txtOtherHabbits.delegate = self
        txtMedication.delegate = self
        
        txtHealthStatus.addTarget(self, action: #selector(txtHealthStatusValueChange), for: .editingChanged)
        txtBreakfastMorning.addTarget(self, action: #selector(txtBreakfastMorningValueChange), for: .editingChanged)
        txtLunch.addTarget(self, action: #selector(txtLunchValueChange), for: .editingChanged)
        txtBreakfastEvening.addTarget(self, action: #selector(txtBreakfastEveningValueChange), for: .editingChanged)
        txtDinner.addTarget(self, action: #selector(txtDinnerValueChange), for: .editingChanged)
        txtOtherHabbits.addTarget(self, action: #selector(txtOtherHabbitsValueChange), for: .editingChanged)
        txtMedication.addTarget(self, action: #selector(txtMedicationValueChange), for: .editingChanged)
        
        
    }
    
    //-----------------------------
    // MARK: Delegate Methods
    //-----------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        self.view.endEditing(true)
        return true
    }
    
    
    //-----------------------------
    // MARK: User Defined Functions
    //-----------------------------
    
    @objc func txtHealthStatusValueChange()
    {
        if txtHealthStatus.text == ""
        {
            lblHealthStatusError.isHidden = false
        }
        else
        {
            lblHealthStatusError.isHidden = true
        }
    }
    @objc func txtBreakfastMorningValueChange()
    {
        if txtBreakfastMorning.text == ""
        {
            lblBreakfastMorningError.isHidden = false
        }
        else
        {
            lblBreakfastMorningError.isHidden = true
        }
    }
    @objc func txtLunchValueChange()
    {
        if txtLunch.text == ""
        {
            lblLunchError.isHidden = false
        }
        else
        {
            lblLunchError.isHidden = true
        }
    }
    @objc func txtBreakfastEveningValueChange()
    {
        if txtBreakfastEvening.text == ""
        {
            lblBreakfastEveningError.isHidden = false
        }
        else
        {
            lblBreakfastEveningError.isHidden = true
        }
    }
    @objc func txtDinnerValueChange()
    {
        if txtDinner.text == ""
        {
            lblDinnerError.isHidden = false
        }
        else
        {
            lblDinnerError.isHidden = true
        }
    }
    @objc func txtOtherHabbitsValueChange()
    {
        if txtOtherHabbits.text == ""
        {
            lblOtherHabbitsError.isHidden = false
        }
        else
        {
            lblOtherHabbitsError.isHidden = true
        }
    }
    @objc func txtMedicationValueChange()
    {
        if txtMedication.text == ""
        {
            lblMedicationError.isHidden = false
        }
        else
        {
            lblMedicationError.isHidden = true
        }
    }
    
    
    
    //-----------------------------
    // MARK: Button Actions
    //-----------------------------
    
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnNextTUI(_ sender: UIButton)
    {
        
        if txtHealthStatus.text! == ""
        {
            lblHealthStatusError.isHidden = false
        }
        else if txtBreakfastMorning.text! == ""
        {
            lblBreakfastMorningError.isHidden = false
        }
        else if txtLunch.text! == ""
        {
            lblLunchError.isHidden = false
        }
        else if txtBreakfastEvening.text! == ""
        {
            lblBreakfastEveningError.isHidden = false
        }
        else if txtDinner.text! == ""
        {
            lblDinnerError.isHidden = false
        }
        else if txtOtherHabbits.text! == ""
        {
            lblOtherHabbitsError.isHidden = false
        }
        else if txtMedication.text! == ""
        {
            lblMedicationError.isHidden = false
        }
        else
        {
            let obj = storyboard?.instantiateViewController(withIdentifier: "MNTForm2VC") as! MNTForm2VC
            navigationController?.pushViewController(obj, animated: true)
        }
        
    }
    
    
    //-----------------------------
    // MARK: Web Services
    //-----------------------------
    
    
}
