//
//  IdentificationVC.swift
//  NutriLife
//
//

import UIKit

class IdentificationVC: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    
    
    
    //----------------------------------
    // MARK: Outlets
    //----------------------------------
    
    @IBOutlet weak var selectRoleView: UIView!
    
    @IBOutlet weak var selectSubRoleView: UIView!
    
    @IBOutlet weak var RoleView: UIView!
    
    @IBOutlet weak var subRoleView: UIView!
    
    @IBOutlet weak var btnSubRole: UIButton!
    
    @IBOutlet weak var btnRole: UIButton!
    
    @IBOutlet weak var tblRole: UITableView!
    
    @IBOutlet weak var tblSubRole: UITableView!
    //----------------------------------
    // MARK: Identifiers
    //----------------------------------
    
    var roleList = ["Service Provider","Patient"]
    var subRoleList = ["Doctor","Dietitian", "Nutritionist",  "Nurse", "Health Educator", "Certified Nutritionist", "Registered Dietitian Nutritionist"]
    var role = 1
    var subRole = 1
    
    //----------------------------------
    // MARK: View Life Cycle
    //----------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        tblRole.isHidden = true
        tblSubRole.isHidden = true
        
        
        RoleView.layer.borderColor = UIColor.lightGray.cgColor
        RoleView.layer.borderWidth = 1
        
        subRoleView.layer.borderColor = UIColor.lightGray.cgColor
        subRoleView.layer.borderWidth = 1
        // Do any additional setup after loading the view.
    }
    
    //----------------------------------
    // MARK: Delegate Methods
    //----------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if tableView.tag == 13
        {
            return subRoleList.count
        }
        else
        {
            return roleList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tblSubRole.dequeueReusableCell(withIdentifier: "tblCellRole") as! tblCellRole
        if tableView.tag == 13
        {
           cell.lblRole[0].text = subRoleList[indexPath.row]
            
        }
        else
        {
            cell.lblRole[0].text = roleList[indexPath.row]
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if tableView.tag == 13
        {
            btnSubRole.setTitle(subRoleList[indexPath.row], for: .normal)
            tblSubRole.isHidden = true
            subRole = indexPath.row
        }
        else
        {
            btnRole.setTitle(roleList[indexPath.row], for: .normal)
            role = indexPath.row + 1
            if indexPath.row == 1
            {
                
                selectSubRoleView.isHidden = true
            }
            else
            {
                selectSubRoleView.isHidden = false
            }
            tblRole.isHidden = true
        }
    }
    
    //----------------------------------
    // MARK: Button Actions
    //----------------------------------

    @IBAction func btnBackTUI(_ sender: UIButton)
    {
       navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func btnRoleTUI(_ sender: UIButton)
    {
        UserDefaults.standard.set("Service Provider", forKey: "role")
        tblSubRole.isHidden = true
        tblRole.isHidden = false
    }
    
    @IBAction func btnSubRoleTUI(_ sender: UIButton)
    {
        
        tblRole.isHidden = true
        tblSubRole.isHidden = false
    }
    
    @IBAction func btnNextTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "RegisterVC") as! RegisterVC
        
        if role == 1
        {
            obj.role = role
            obj.subRole = subRole
        }
        else
        {
            obj.role = role
            obj.subRole = 0
        }
        navigationController?.pushViewController(obj, animated: true)
    }
    
}
