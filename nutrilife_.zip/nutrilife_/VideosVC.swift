//
//  VideosVC.swift
//  NutriLife
//
//  
//

import UIKit
import Alamofire
import SVProgressHUD

class VideosVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    //-----------------------------
    // MARK: Outlets
    //-----------------------------
    
    @IBOutlet weak var tblVideos: UITableView!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var btnAdd: UIButton!
    
    @IBOutlet weak var lblTitle: UILabel!
    

    
    //-----------------------------
    // MARK: Identifiers
    //-----------------------------
    
    var timer = Timer()
    var videodata = NSMutableArray()
    var doc_video_id = Int()
    
    //-----------------------------
    // MARK: View Life Cycle
    //-----------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()

        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
        {
            lblTitle.text = "My Videos"
            btnAdd.isHidden = false
            videos()
        }
        else
        {
            lblTitle.text = "Videos"
            btnAdd.isHidden = true
            videospatient()
        }
    }
    

    
    
    
    
    
    
    
    //-----------------------------
    // MARK: Delegate Methods
    //-----------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return videodata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let obj = tblVideos.dequeueReusableCell(withIdentifier: "tblCellVIdeo") as! tblCellVIdeo
        let dic = videodata[indexPath.row] as! NSDictionary
        
        if UserDefaults.standard.string(forKey: "userrole") == "doctor"
            
        {
            obj.videoSwitch.layer.cornerRadius = obj.videoSwitch.frame.height/2
            obj.lblVideoName.text = (dic["video_name"] as! String)
            obj.lblVideoDescription.text = (dic["description"] as! String)
            obj.videoSwitch.isHidden = false
            if (dic["status"] as! Int) == 0
            {
                obj.videoSwitch.isOn = false
            }
            else
            {
                obj.videoSwitch.isOn = true
            }
            obj.videoSwitch.tag = (dic["doc_video_id"] as! Int)
        }
        else
        {
            obj.videoSwitch.isHidden = true
            obj.lblVideoName.text = (dic["video_name"] as! String)
            obj.lblVideoDescription.text = (dic["description"] as! String)
        }
        return obj
      }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let dic = videodata[indexPath.row] as! NSDictionary
        let obj = storyboard?.instantiateViewController(withIdentifier: "VideoDetailsVC") as! VideoDetailsVC
        obj.video = dic
        
        navigationController?.pushViewController(obj, animated: true)
        
        
//        certititle = (dic["name"] as! String)
//        certidisc = (dic["description"] as! String)
        

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return UITableView.automaticDimension
        
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return UITableView.automaticDimension
    }
    
    //-----------------------------
    // MARK: User Defined Functions
    //-----------------------------

    
        @objc func InternetAvailable()
        {
            if Connectivity.isConnectedToInternet()
            {
                videos()
            }
            else
            {
                SVProgressHUD.dismiss()
                PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
            }
        }
    
    //-----------------------------
    // MARK: Button Actions
    //-----------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnAddTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "AddVideoVC") as! AddVideoVC
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    
    @IBAction func btnVideoAvailability(_ sender: UISwitch)
    {
        doc_video_id = sender.tag
        videovisibility()
    }
    
    
    //-----------------------------
    // MARK: Web Services
    //-----------------------------
    
//    http://35.187.227.141/api/doctor/videos
    
    
    
//    "{
//    ""doc_id"":3
//}"

    
    
    
//    "{
//    ""msg"": ""2 videos available"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""doc_video_id"": 2,
//    ""name"": ""Introductions and the"",
//    ""video"": ""http://35.187.227.141/storage/uploads/fileexampleMP448015MG_1542113993.mp4"",
//    ""description"": ""Lorem Ipsum is simply a white male dummy text of the printing and typesetting industry"",
//    ""views"": 16,
//    ""status"": 1
//    },
//    {
//    ""doc_video_id"": 28,
//    ""name"": ""Helo since the"",
//    ""video"": ""http://35.187.227.141/storage/uploads/fileexampleMP448015MG_1543059407.mp4"",
//    ""description"": ""Democrats to"",
//    ""views"": 5,
//    ""status"": 1
//    }
//    ]
//}"
    
    
    
    func videos()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_id" : UserDefaults.standard.integer(forKey: "userId")] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/videos" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("2 videos available")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            self.videodata = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblVideos.reloadData()
            
                            
                            SVProgressHUD.dismiss()
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
            
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    
//    http://35.187.227.141/api/doctor/video_status
    
    
    
//    "{
//    ""doc_video_id"":2
//}"
    
    
//    "{
//    ""msg"": ""Success! Video visibility changed"",
//    ""status"": 1,
//    ""visibility"": 0
//}"
    
    
    
    
    
    
    func videovisibility()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        let parameter = ["doc_video_id" : doc_video_id ] as [String : Any]
        print(parameter)
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "doctor/video_status" , method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("Success! Video visibility changed")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            SVProgressHUD.dismiss()
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
    }
    
    
    
    
//    http://35.187.227.141/api/patient/allvideos
    
    
    
//    None
    
    
    
//    "{
//    ""msg"": ""1 videos available"",
//    ""status"": 1,
//    ""data"": [
//    {
//    ""video_id"": 2,
//    ""doctor"": ""Shreeraj Jadeja"",
//    ""video_name"": ""Intro"",
//    ""views"": 5,
//    ""video"": ""http://http://35.187.227.141/storage/uploads/Introforapp_1540453312.m4a"",
//    ""description"": ""Lorem Ipsum is simply dummy text of the printing and typesetting industry""
//    }
//    ]
//}"
    
    
    
    
    func videospatient()
    {
        
        let header: HTTPHeaders = ["Content-Type": "application/json", "token": "11Z1yzMEte4w6T1Pktpk"]
        if Connectivity.isConnectedToInternet()
        {
            timer.invalidate()
            SVProgressHUD.show()
            
            Alamofire.request( appDelegate.apiString + "patient/allvideos" , method: .get, parameters: nil, encoding: JSONEncoding.default, headers: header).validate().responseJSON
                {
                    response in
                    switch response.result
                    {
                    case .success:
                        print("1 videos available")
                        let result = response.result.value! as! NSDictionary
                        print(result)
                        if (result["status"] as! Int) == 0
                        {
                            PopUp(Controller: self, title: "Error!", message: (result["msg"] as! String))
                            SVProgressHUD.dismiss()
                        }
                        else
                        {
                            self.videodata = (result["data"] as! NSArray).mutableCopy() as! NSMutableArray
                            self.tblVideos.reloadData()
                            
                            
                            SVProgressHUD.dismiss()
                            
                            
                        }
                        
                        
                    case .failure(let error):
                        print(error)
                    }
            }
            
        }
            
        else
        {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.InternetAvailable), userInfo: nil, repeats: true)
            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
        }
        
        
    }
    
    
    
}
